<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } [$title, $total] = dj_archive_meta($this); ?>
<h3 class="archive-title">
    <?php echo dj_e($title); ?> <em><?php echo $total; ?></em> 篇
</h3>
