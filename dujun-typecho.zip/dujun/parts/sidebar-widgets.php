<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } ?>
<section class="widget">
    <ul class="widget-list">
        <li>
            <?php \Widget\Contents\Page\Rows::allocWithAlias($djPageRowsAlias ?? 'nav')->to($pages); ?>
            <?php while ($pages->next()): ?>
                <a class="content<?php if ($this->is('page', $pages->slug)): ?> active<?php endif; ?>"
                   href="<?php $pages->permalink(); ?>"><?php $pages->title(); ?></a>
            <?php endwhile; ?>
        </li>
    </ul>
</section>

<?php if ($this->options->sidebarTag !== '0'): ?>
    <section class="widget">
        <span class="widget-title"><?php _e('标签'); ?></span>
        <ul class="widget-list">
            <li>
                <?php \Widget\Metas\Tag\Cloud::alloc()->to($tags); ?>
                <?php while ($tags->next()): ?>
                    <a class="archive" href="<?php $tags->permalink(); ?>"><?php $tags->name(); ?></a>
                <?php endwhile; ?>
            </li>
        </ul>
    </section>
<?php endif; ?>

<?php if ($this->options->sidebarArchive !== '0'): ?>
    <section class="widget">
        <span class="widget-title"><?php _e('归档'); ?></span>
        <ul class="widget-list">
            <li class="years">
                <?php \Widget\Contents\Post\Date::alloc('format=Y&type=year')->to($dates); ?>
                <?php while ($dates->next()): ?>
                    <a class="archive" href="<?php $dates->permalink(); ?>"><?php echo $dates->year; ?></a>
                <?php endwhile; ?>
            </li>
        </ul>
    </section>
<?php endif; ?>

<section class="widget latest-comments">
    <span class="widget-title"><?php _e('评论'); ?></span>
    <ul class="widget-list">
        <?php \DjRecentComments::alloc(['ignoreAuthor' => true])->to($comments); ?>
        <?php if ($comments->have()): ?>
            <?php while ($comments->next()): ?>
                <?php  ?>
                <li><a class="content" href="<?php $comments->permalink(); ?>"
                       title="<?php echo dj_e(dj_site_date('Y-m-d H:i', (int)$comments->created)); ?>">
                        <?php echo dj_e($comments->author ? : '佚名'); ?>: <?php echo dj_e($comments->text); ?><br>
                        <i class="i-related"></i>《<?php echo dj_e((string)$comments->title); ?>》
                    </a></li>
            <?php endwhile; ?>
        <?php else: ?>
            <li><?php _e('暂无评论'); ?></li>
        <?php endif; ?>
    </ul>
</section>

<section class="widget">
    <span class="widget-title"><?php _e('其它'); ?></span>
    <ul class="widget-list">
        <?php if ($this->user->hasLogin()): ?>
            <li><a class="content" href="<?php $this->options->adminUrl(); ?>"><?php _e('进入后台'); ?> (<?php $this->user->screenName(); ?>)</a></li>
        <?php else: ?>
            <li><a class="content" href="<?php $this->options->adminUrl('login.php'); ?>"><?php _e('登录'); ?></a></li>
        <?php endif; ?>
        <li><a class="content" href="<?php $this->options->feedUrl(); ?>"><?php _e('文章 RSS'); ?></a></li>
        <li><a class="content" href="<?php $this->options->commentsFeedUrl(); ?>"><?php _e('评论 RSS'); ?></a></li>
    </ul>
</section>
