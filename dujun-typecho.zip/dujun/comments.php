<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } ?>
<?php \DjComments::alloc([ 'parentId' => $this->hidden ? 0 : $this->cid, 'parentContent' => $this, 'respondId' => $this->respondId, 'commentPage' => $this->parameter->commentPage, 'allowComment' => $this->allow('comment') ])->to($comments); ?>
<div id="comment"<?php if (!empty($GLOBALS['dj_new_comment_coid'])): ?> data-new-comment="comment-<?php echo (int)$GLOBALS['dj_new_comment_coid']; ?>"<?php endif; ?>>
    <?php if ($comments->have()): ?>
        <span class="widget-title"><?php
 $djCnt = $comments->djCommentTotal(); if ($djCnt <= 0) { echo _t('暂无评论'); } elseif (1 == $djCnt) { echo _t('1 条评论'); } else { echo _t('%d 条评论', $djCnt); } ?></span>
        <ul class="comment-list">
            <?php $comments->listComments(['before' => '', 'after' => '']); ?>
        </ul>
        <?php $comments->pageNav(dj_icon('previous'), dj_icon('next'), 3, '…', 'wrapTag=ol&wrapClass=page-number'); ?>
    <?php endif; ?>

    <?php if ($this->allow('comment')): ?>
        <div class="comment-form" id="respond-post-<?php $this->cid(); ?>">
            
            <div class="comment-cancel-reply"><?php $comments->cancelReply(); ?></div>
            <span class="widget-title comment-form-title"><?php _e('添加评论'); ?></span>
            <form method="post" action="<?php echo \Widget\Security::alloc()->getTokenUrl($this->commentUrl); ?>" class="clearfix">
                <div class="comment-textarea">
                    <p>
                    <textarea name="text"
                              placeholder="<?php _e('说点什么吧'); ?>" required><?php $this->remember('text'); ?></textarea>
                    </p>
                </div>
                <?php
 $guestRememberAuthor = (!$this->user->hasLogin()) ? trim((string)\Typecho\Cookie::get('__typecho_remember_author', '')) : ''; $guestRememberMail = (!$this->user->hasLogin()) ? trim((string)\Typecho\Cookie::get('__typecho_remember_mail', '')) : ''; $guestRememberUrl = (!$this->user->hasLogin()) ? trim((string)\Typecho\Cookie::get('__typecho_remember_url', '')) : ''; $djShowAvatar = ('' !== $guestRememberAuthor && '' !== $guestRememberMail && '' !== $guestRememberUrl); ?>
                <div class="comment-input<?php if ($djShowAvatar): ?> show-avatar<?php endif; ?>">
                    <?php if ($this->user->hasLogin()): ?>
                        <img class="admin-avatar"
                             src="<?php echo dj_e(dj_gravatar_url((string)$this->user->mail, 80, (string)$this->options->commentsAvatarRating)); ?>"
                             alt="<?php $this->user->screenName(); ?>" width="60" height="60">
                        <span class="admin-name"><?php $this->user->screenName(); ?><a
                                    href="<?php $this->options->logoutUrl(); ?>"><?php _e('退出'); ?></a></span>
                    <?php else: ?>
                        <?php if ($djShowAvatar): ?>
                            <img class="guest-avatar"
                                 src="<?php echo dj_e(dj_gravatar_url($guestRememberMail, 80, (string)$this->options->commentsAvatarRating)); ?>"
                                 alt="<?php echo dj_e($guestRememberAuthor); ?>" width="60" height="60">
                            <span class="guest-name" title="<?php _e('点击修改'); ?>"><?php echo dj_e($guestRememberAuthor); ?></span>
                        <?php endif; ?>
                        <p class="comment-field">
                            <?php  ?>
                            <input type="text" name="author" placeholder="<?php _e('名称'); ?>" autocomplete="on" required
                                   value="<?php $this->remember('author'); ?>">
                            <label class="i-comment-author"></label>
                        </p>
                        <p class="comment-field">
                            <input type="email" name="mail" placeholder="<?php _e('邮箱'); ?>" autocomplete="on"
                                   value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?>>
                            <label class="i-email"></label>
                        </p>
                        <p class="comment-field">
                            <input type="url" name="url" placeholder="<?php _e('网址'); ?>" autocomplete="on"
                                   value="<?php $this->remember('url'); ?>"<?php if ($this->options->commentsRequireUrl): ?> required<?php endif; ?>>
                            <label class="i-comment-url"></label>
                        </p>
                    <?php endif; ?>
                    <p class="comment-submit">
                        <button type="submit" disabled><?php _e('提交评论'); ?></button>
                    </p>
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
    <?php else: ?>
        <span class="widget-title"><?php _e('评论已关闭'); ?></span>
    <?php endif; ?>
</div>
