<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover,user-scalable=no,shrink-to-fit=no">
    <meta name="renderer" content="webkit">
    <title><?php _e('404 - 页面不存在'); ?> - <?php $this->options->title(); ?></title>
    <link rel="stylesheet" href="<?php echo dj_asset('css/main.css'); ?>">
    <link rel="stylesheet" href="<?php echo dj_asset('css/error.css'); ?>">
    <?php $this->header(); ?>
</head>
<body class="error-body">
<div class="error-main">
    <div class="error-container">
        <header class="clearfix">
            <div class="error-title">404</div>
        </header>
        <section>
            <div class="error-text">
                <p><?php _e('雷霆雨露　俱是天恩'); ?></p>
            </div>
            <a class="index error-button"
               href="<?php $this->options->siteUrl(); ?>"><?php _e('前往首页'); ?></a>
        </section>
        <footer class="error-footer">
            &copy; <?php echo date('Y'); ?> <?php $this->options->title() ?>.
        </footer>
    </div>
</div>
<?php $this->footer(); ?>
</body>
</html>
