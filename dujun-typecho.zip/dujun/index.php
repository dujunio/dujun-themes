<?php
/**
 * 一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。
 *
 * @package 杜郎俊赏
 * @author dujun
 * @version 1.0.3
 * @link https://dujun.io
 */

 if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } $this->need('header.php'); $keyword = $this->is('search') ? dj_search_keyword() : ''; $isSearchLanding = isset($_GET['search']); if ($isSearchLanding): ?>
    
    <section class="widget search">
        <form method="post" action="<?php $this->options->siteUrl(); ?>">
            <input type="text" name="s" class="search-input"
                   placeholder="<?php _e('输入关键词'); ?>" autocomplete="on" autofocus>
            <?php echo dj_icon('search'); ?>
        </form>
    </section>
    <div class="sidebar nav-sidebar">
        <?php $djPageRowsAlias = 'navSearch'; ?>
        <?php $this->need('parts/sidebar-widgets.php'); ?>
    </div>
    <?php $this->need('footer.php'); return; ?>
<?php endif; ?>

<?php if (!$this->is('index')): ?>
    <?php $this->need('parts/archive-title.php'); ?>
<?php endif; ?>

<?php if ($this->have()): ?>
    <?php while ($this->next()): ob_start(); $this->content(false); $postHtml = ob_get_clean(); $cover = ''; if (preg_match('/<img[^>]*\ssrc="([^"]+)"/i', $postHtml, $m)) { $cover = dj_cover_url($m[1]); } ob_start(); $this->excerpt(180, '……'); $excerpt = ob_get_clean(); if ($keyword !== ''): $djClean = dj_strip_md_syntax(strip_tags($postHtml)); if (mb_stripos($djClean, $keyword) === false) { continue; } $excerpt = dj_strip_md_syntax($excerpt); endif; ?>
        <article>
            <h2 class="article-title">
                <a class="content" href="<?php $this->permalink() ?>"><?php echo $keyword ? dj_highlight(dj_e($this->title), $keyword) : dj_e($this->title); ?></a>
            </h2>
            <div>
                <?php if ($cover !== ''): ?>
                    <a class="content" href="<?php $this->permalink() ?>">
                        <div class="summary-cover">
                            <div class="summary-cover-inner">
                                <img src="<?php echo dj_e(dj_https($cover)); ?>" alt="" loading="lazy">
                            </div>
                        </div>
                    </a>
                <?php endif; ?>
                <div class="summary-text-inner">
                    <a class="content" href="<?php $this->permalink() ?>"><?php echo $keyword ? dj_highlight($excerpt, $keyword) : $excerpt; ?></a>
                </div>
            </div>
            <div class="article-meta clearfix">
                <span><?php echo dj_relative_time((int)$this->created); ?></span>
                <?php if ($this->allow('comment')): ?>
                    ｜ <a class="content" href="<?php $this->permalink() ?>#comment"><?php $this->commentsNum(_t('评论'), _t('1 评论'), _t('%d 评论')); ?></a>
                <?php endif; ?>
            </div>
        </article>
    <?php endwhile; ?>
<?php endif; ?>

<?php dj_page_nav($this); ?>
<?php $this->need('footer.php'); ?>
