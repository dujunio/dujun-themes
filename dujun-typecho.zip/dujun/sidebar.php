<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } ?>
<div class="sidebar">
    <section class="widget search">
        <form method="post" action="<?php $this->options->siteUrl(); ?>">
            <input type="text" name="s" class="search-input"
                   placeholder="<?php _e('输入关键词'); ?>" autocomplete="on">
            <?php echo dj_icon('search'); ?>
        </form>
    </section>

    <?php $djPageRowsAlias = 'nav'; ?>
    <?php $this->need('parts/sidebar-widgets.php'); ?>
</div>
