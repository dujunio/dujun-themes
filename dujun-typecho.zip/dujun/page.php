<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } $this->need('header.php'); ?>
<article id="content">
    <h1 class="article-title"><?php $this->title() ?></h1>
    <div class="article-content">
        <?php ob_start(); $this->content(); echo dj_content_images(dj_https(ob_get_clean())); ?>
    </div>
    <div class="article-meta clearfix">
        <span><?php $this->date('Y 年 m 月 d 日'); ?></span>
    </div>
</article>
<?php $this->need('comments.php'); ?>
<?php $this->need('footer.php'); ?>
