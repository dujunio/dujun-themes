<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } ?>
</div>
</div>
<?php $this->need('sidebar.php'); ?>
</div>
</div>

<footer class="footer">
    <div class="container">
        <span class="footer-line">&copy; <?php echo date('Y'); ?> <?php $this->options->title() ?>.</span>
        <span class="footer-line">Powered by <a href="https://typecho.org" target="_blank" rel="nofollow" style="margin-right:0">Typecho</a>. Theme by <a href="https://dujun.io" target="_blank" rel="nofollow" style="margin-right:0">dujun</a>.</span>
        <?php
 $footerExtras = []; if (!empty($this->options->icpNumber)) { $footerExtras[] = '<a class="footer-beian" href="https://beian.miit.gov.cn" target="_blank" rel="nofollow" style="margin-right:0">' . dj_e($this->options->icpNumber) . '</a>'; } if (!empty($this->options->policeNumber)) { $footerExtras[] = '<a class="footer-beian" href="https://www.beian.gov.cn" target="_blank" rel="nofollow" style="margin-right:0">' . dj_e($this->options->policeNumber) . '</a>'; } if (!empty($this->options->footerText)) { $footerExtras[] = dj_e($this->options->footerText); } if (count($footerExtras)) { echo '<span class="footer-line">' . implode('. ', $footerExtras) . '.</span>'; } ?>
    </div>
</footer>
<script src="<?php echo dj_asset('js/main.js'); ?>"></script>
<script src="<?php echo dj_asset('js/article.js'); ?>"></script>
<?php $this->footer(); ?>
</body>
</html>
