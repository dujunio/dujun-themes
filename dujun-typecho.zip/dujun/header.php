<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } ?>
<!DOCTYPE html>
<?php
$_dj_dc = dj_html_dark_class(); $_dj_dark = $_dj_dc ? trim(substr($_dj_dc, 8), '"') : ''; \Widget\Metas\Category\Rows::alloc('nav')->to($djCats); $djNavCats = []; while ($djCats->next()) { $djNavCats[] = [ 'slug' => (string)$djCats->slug, 'name' => (string)$djCats->name, 'permalink' => (string)$djCats->permalink, ]; } $djNavCategory = ''; if ($this->is('post')) { foreach (array_reverse(array_filter((array)$this->directory, static fn($s) => '' !== (string)$s)) as $djSlug) { foreach ($djNavCats as $djNavCat) { if ($djNavCat['slug'] === (string)$djSlug) { $djNavCategory = (string)$djSlug; break 2; } } } } ?>
<html lang="zh-CN" class="han-init<?php echo $_dj_dark ? ' ' . $_dj_dark : ''; ?>">
<head>
    <meta charset="<?php $this->options->charset(); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover,user-scalable=no,shrink-to-fit=no">
    <meta name="HandheldFriendly" content="true">
    <meta name="format-detection" content="telephone=no,email=no">
    <meta name="renderer" content="webkit">
    <title><?php $this->archiveTitle([ 'category' => _t('分类「%s」'), 'search' => _t('搜索「%s」'), 'tag' => _t('标签「%s」'), 'author' => _t('%s 的文章'), 'date' => '%s 的存档', 'post' => '%s', 'page' => '%s', ], '', ' - '); ?><?php $this->options->title(); ?></title>
    <link rel="stylesheet" href="<?php echo dj_asset('css/main.css'); ?>">
    <?php  ?>
    <link rel="stylesheet" href="<?php echo dj_asset('css/article.css'); ?>">
    <?php if ('' !== ($djSitenameFont = dj_sitename_font_stack())): ?>
    <style>.sitename a{font-family:<?php echo $djSitenameFont; ?>}</style>
    <?php endif; ?>
    <?php $this->header(); ?>
</head>
<body>
<header class="header clearfix">
    <div class="container">
        <div class="column-group">
            <div class="sitename">
                <a class="index" href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title() ?></a>
            </div>
            <div>
                
                <nav class="clearfix"><?php $djSearchUrl = dj_search_page_url(); ?><a class="content nav-search<?php if (isset($_GET['search']) || isset($_GET['s']) || $this->is('search')): ?> active<?php endif; ?>"<?php if ('' === $djSearchUrl): ?> href="#" role="button" data-dj-search<?php else: ?> href="<?php echo $djSearchUrl; ?>"<?php endif; ?>><?php _e('搜索'); ?></a><?php foreach ($djNavCats as $djNavCat): ?><a class="archive<?php if ($this->is('category', $djNavCat['slug']) || $djNavCat['slug'] === $djNavCategory): ?> active<?php endif; ?>" data-dj-category="<?php echo dj_e($djNavCat['slug']); ?>" href="<?php echo dj_e($djNavCat['permalink']); ?>"><?php echo dj_e($djNavCat['name']); ?></a><?php endforeach; ?></nav>
            </div>
        </div>
    </div>
</header>
<div class="container">
    <div class="column-group">
        <div class="main">
            <div class="rescale-container" id="pjax-container"><?php if ('' !== $djNavCategory): ?><div hidden id="dj-nav-state" data-dj-category="<?php echo dj_e($djNavCategory); ?>"></div><?php endif; ?>
