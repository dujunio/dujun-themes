<?php if (!defined('__TYPECHO_ROOT_DIR__')) { exit; } $this->need('header.php'); ?>
<article id="content">
    <h1 class="article-title"><?php $this->title() ?></h1>
    <div class="article-content">
        <?php ob_start(); $this->content(); echo dj_content_images(dj_content_links(dj_https(ob_get_clean()))); ?>
    </div>
    <?php if ($this->tags): ?>
        <div class="article-tag">
            <?php $this->tags('', true, ''); ?>
        </div>
    <?php endif; ?>
    <div class="article-meta clearfix">
        <span><?php echo dj_e(dj_chinese_time((int)$this->created)); ?></span>
        <?php if ($this->user->hasLogin()): ?>
            ｜ <a class="content" href="<?php $this->options->adminUrl(); ?>write-post.php?cid=<?php $this->cid(); ?>" target="_blank" rel="noopener">编辑</a>
        <?php endif; ?>
    </div>
</article>
<?php $this->need('comments.php'); ?>
<?php $this->need('footer.php'); ?>
