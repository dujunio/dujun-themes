# dujun 主题 · Hexo 版

一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。

这是一个**完整的 Hexo 站点模板**，主题放在 `themes/dujun/`，`source/` 里带了一篇示例文章和关于/搜索页面，解压即可生成站点。

## 快速开始

需要 Node.js 20.19+（Hexo 8 要求）。

```bash
cd dujun            # 解压 dujun-hexo.zip 后进入目录
npm install         # 安装依赖（hexo 包自带命令行，无需全局装 hexo-cli）
npx hexo clean
npx hexo generate   # 生成静态文件到 public/
npx hexo server     # 本地预览，默认 http://localhost:4000
```

把 `public/` 目录整个传到任意静态托管（GitHub Pages、Netlify、Vercel、Nginx 等）即可上线，不需要 PHP 或数据库。

## 配置

- **站点信息**：根目录 `_config.yml` —— `title`、`description`、`author`，务必把 `url` 改成你的正式域名（包里默认是 `https://example.com`）
- **主题外观**：`themes/dujun/_config.yml` —— 站名字体、暗色模式、侧栏开关、顶部导航分类、每页篇数等
- **上线域名**：`_config.yml` 的 `url` 会用于固定链接、RSS 和站点地图，改完重新 `npx hexo g`

## 写文章

在 `source/_posts/` 下新建 Markdown 文件，按示例文章的 frontmatter 写：

```yaml
---
title: 文章标题
date: 2026-11-19
description: 摘要
tags: [标签1, 标签2]
categories:
  - [随笔]
---
```

正文照常写 Markdown，支持表格、任务列表、脚注和代码高亮。

## 目录说明

```
_config.yml              站点配置（改域名在这里）
package.json             依赖清单
source/_posts/           文章（示例：markdown.md）
source/about/            关于页
source/search/           搜索页
source/404.md            404 页
themes/dujun/            主题本体
  _config.yml            主题配置
  layout/                EJS 模板
  scripts/               分类/标签/归档路由、搜索索引、RSS、时间算法
  source/assets/         CSS 与 JS
```

## 注意

- 这是静态博客，**没有评论系统**，也不需要后端。
- 改了配置或文章后要重新 `npx hexo g` 才会更新到 `public/`。
- 顶部导航的分类名要写进 `themes/dujun/_config.yml` 的 `nav`，分类页才会出现在导航里。
