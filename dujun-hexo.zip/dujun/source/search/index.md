---
title: 搜索
layout: search
permalink: /search/
description: 一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。
---

搜索页面由主题脚本在前端渲染。
