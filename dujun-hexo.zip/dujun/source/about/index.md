---
title: 关于
layout: page
permalink: /about/
date: 2026-11-14T00:00:00.000Z
description: 一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。
---

这是 dujun 主题的 Hexo 静态版示例站点，用于验证列表、文章、归档、标签与搜索的排版效果。

简洁、克制、阅读优先，把注意力还给文字本身。
