---
title: 'Markdown 元素全家福'
date: 2026-11-15
archive: ['2026']
description: '一篇覆盖标题、强调、链接、图片、列表、引用、代码、表格、任务列表、分隔线、脚注等常用 Markdown 元素的示例文章。'
category: ['随笔', '照片', '文章', '作品']
tag: ['排版', 'markdown', 'demo']
---

## 标题层级

二级标题

### 三级标题

#### 四级标题

##### 五级标题

###### 六级标题

## 段落与行内样式

这是一个普通段落，里面混用了多种行内元素：**加粗**、*斜体*、~~删除线~~、行内代码 `const x = 1`、<mark>HTML 高亮</mark>，以及一个键盘键 <kbd>Esc</kbd>。

## 链接

- 普通外链：[杜郎俊赏](https://dujun.io)
- 带 title 的链接：[Hugo 官网](https://gohugo.io "Hugo 静态站点生成器")
- 站内链接：[返回首页](/)

自动链接：<https://example.com>

## 图片

![随机图片](./random-photo.jpg "随机图片")

## 列表

### 无序列表

- 苹果
- 香蕉
  - 进口香蕉
  - 本地香蕉
- 橙子

### 有序列表

1. 准备材料
2. 开始写作
   1. 列提纲
   2. 填充正文
3. 校对发布

### 任务列表

- [x] 安装 Hugo 扩展版
- [x] 启用 Goldmark 脚注
- [ ] 校对排版
- [ ] 发布上线

## 引用

> 这是一级引用，用来强调一段话。
>
> > 这是嵌套在里面的二级引用。

## 代码块

### JavaScript

```js
function greet(name) {
    return `Hello, ${name}!`;
}
console.log(greet('Markdown'));
```

### Python

```python
def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
```

### Bash

```bash
hugo build --minify
```

### JSON

```json
{
    "name": "dujun",
    "version": "1.0.3",
    "hugo": true
}
```

## 表格

| 元素 | 左对齐 | 居中 | 右对齐 |
| :--- | :--- | :---: | ---: |
| 行内代码 | `code` | *斜体* | **粗体** |
| 链接 | [dujun.io](https://dujun.io) | — | 100.00 |
| 长文本 | 表格单元格里的长文本会自动换行 | 居中内容 | 1,234.56 |

## 分隔线

---

## 脚注

正文里可以放一个脚注引用[^note]，它会落到文章末尾。

[^note]: 这是脚注的具体内容，用来补充正文信息。

## 折叠块

<details>
<summary>点击展开更多</summary>

这里是被折叠起来的补充内容。

</details>
