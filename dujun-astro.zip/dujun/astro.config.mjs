// @ts-check
import { defineConfig } from 'astro/config';
import remarkGfm from 'remark-gfm';
import remarkFootnotes from 'remark-footnotes';

// https://astro.build/config
export default defineConfig({
    site: 'https://example.com',
    markdown: {
        /* 关闭 Shiki：代码高亮统一交给共用 article.js 内嵌的 Prism，
           配色才能与 article.css 的 .token.* 规则一致 */
        syntaxHighlight: false,
        remarkPlugins: [remarkGfm, remarkFootnotes],
    },
    vite: {
        server: {
            /* 本地开发允许的 host；部署者按需改成自己的域名 */
            allowedHosts: ['example.com', 'localhost'],
        },
    },
});
