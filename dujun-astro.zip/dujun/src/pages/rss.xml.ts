import type { APIRoute } from 'astro';
import { getPosts, postUrl } from '../lib/posts';
import { SITE_TITLE, SITE_URL, THEME_DESCRIPTION } from '../config';

function cdata(value: string): string {
    return `<![CDATA[${value.replace(/]]>/g, ']]]]><![CDATA[>')}]]>`;
}

export const GET: APIRoute = async () => {
    const posts = await getPosts();
    const items = posts.map((post) => {
        const link = new URL(postUrl(post), SITE_URL).href;
        return `<item><title>${cdata(post.data.title)}</title><link>${link}</link><guid>${link}</guid><pubDate>${post.data.date.toUTCString()}</pubDate><description>${cdata(post.data.description)}</description></item>`;
    }).join('');
    const xml = `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>${cdata(SITE_TITLE)}</title><link>${SITE_URL}/</link><description>${cdata(THEME_DESCRIPTION)}</description>${items}</channel></rss>`;
    return new Response(xml, {
        headers: { 'Content-Type': 'application/rss+xml; charset=utf-8' },
    });
};
