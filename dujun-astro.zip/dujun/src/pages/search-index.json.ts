import type { APIRoute } from 'astro';
import { getPosts, postUrl, excerpt, plainText, cover } from '../lib/posts';
import { relativeTime } from '../lib/time';

export const GET: APIRoute = async () => {
    const posts = await getPosts();
    const index = posts.map((post) => ({
        title: post.data.title,
        url: postUrl(post),
        description: post.data.description,
        excerpt: excerpt(post),
        cover: cover(post),
        category: post.data.category,
        tags: post.data.tags,
        date: post.data.date.toISOString(),
        time: relativeTime(post.data.date),
        text: plainText(post),
    }));
    return new Response(JSON.stringify(index), {
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
    });
};
