import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';


export const THEME_DESCRIPTION =
    '一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。';
export const THEME_VERSION = '1.0.0';
export const SITE_TITLE = 'Dujun Theme';
export const SITE_URL = 'https://example.com';
export const THEME_HOME = 'https://dujun.io';
export const THEME_REPO = 'https://github.com/dujunio/dujun-themes';

export const config = {
    
    sitenameFont: '"LiSu", "STLiti", serif' as string,
    icpNumber: '',
    policeNumber: '',
    footerText: '',
    dark: 'auto' as 'auto' | 'light' | 'dark',
    sidebarTag: true,
    sidebarArchive: true,
    
    nav: ['随笔', '照片', '文章', '作品'] as string[],
    postsPerPage: 10,
};


function layerHash(path: string): string {
    if (!/(?:^|\/)main\.(?:css|js)$/.test(path)) return '';
    try {
        const file = join(process.cwd(), 'public/assets', path);
        return createHash('sha1').update(readFileSync(file)).digest('hex').slice(0, 8);
    } catch {
        return '';
    }
}

export function asset(path: string): string {
    const h = layerHash(path);
    return `/assets/${path}?v=${THEME_VERSION}${h ? '&h=' + h : ''}`;
}
