export type PagerItem =
    | { kind: 'prev' | 'next'; page: number }
    | { kind: 'page' | 'first' | 'last'; page: number; active?: boolean }
    | { kind: 'delimiter' };


export function pageItems(current: number, total: number): PagerItem[] {
    if (total < 2) return [];

    let split = 2;
    if (total < 9) split = 9;
    else if (current < 4) split = 5 - current;
    else if (total - 4 < current) split = 5 + current - total;

    const from = Math.max(1, current - split);
    const to = Math.min(total, current + split);
    const items: PagerItem[] = [];

    if (current > 1) items.push({ kind: 'prev', page: current - 1 });
    if (from > 1) {
        items.push({ kind: 'first', page: 1 });
        if (from > 2) items.push({ kind: 'delimiter' });
    }
    for (let i = from; i <= to; i++) {
        items.push({ kind: 'page', page: i, active: i === current });
    }
    if (to < total) {
        if (to < total - 1) items.push({ kind: 'delimiter' });
        items.push({ kind: 'last', page: total });
    }
    if (current < total) items.push({ kind: 'next', page: current + 1 });

    return items;
}


export function pageUrl(page: number, base = '/'): string {
    const root = base === '/' ? '' : base.replace(/\/$/, '');
    return page <= 1 ? (root || '/') : `${root}/page/${page}/`;
}

export function paginate<T>(items: T[], page: number, perPage: number): T[] {
    return items.slice((page - 1) * perPage, page * perPage);
}

export function totalPages(count: number, perPage: number): number {
    return Math.max(1, Math.ceil(count / perPage));
}
