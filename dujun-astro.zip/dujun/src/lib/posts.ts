import { getCollection, type CollectionEntry } from 'astro:content';

export type Post = CollectionEntry<'blog'>;

export interface Term {
    name: string;
    slug: string;
    count: number;
}

const SLUGS: Record<string, string> = {
    技术笔记: 'notes',
    日常随笔: 'essays',
    搜索: 'search',
    占位: 'placeholder',
    照片: 'photos',
    文章: 'articles',
    作品: 'works',
    随笔: 'essay',
    排版: 'typography',
    test: 'test',
};

export function slugFor(name: string): string {
    if (SLUGS[name]) return SLUGS[name];
    const ascii = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    return ascii || 'item';
}

export async function getPosts(): Promise<Post[]> {
    const posts = await getCollection('blog');
    return posts.sort((a, b) => b.data.date.valueOf() - a.data.date.valueOf());
}

export function postUrl(post: Post): string {
    return `/blog/${post.id}/`;
}

export function excerpt(post: Post, limit = 180): string {
    const text = post.data.description || '';
    return text.length > limit ? `${text.slice(0, limit)}……` : text;
}


const contentImages = import.meta.glob<string>(
    '/src/content/blog/**/*.{jpg,jpeg,png,webp,gif,svg}',
    { eager: true, import: 'default', query: '?url' },
);


function resolveImage(src: string, post: Post): string {
    if (!/^\.\.?\//.test(src)) return src;
    const name = src.replace(/^\.\//, '');
    const candidates = [
        `/src/content/blog/${name}`,
        `/src/content/blog/${post.id}/${name}`,
    ];
    for (const key of candidates) {
        if (contentImages[key]) return contentImages[key];
    }
    return src;
}


export function cover(post: Post): string {
    const body = post.body || '';
    const md = body.match(/!\[[^\]]*\]\(([^)\s]+)/);
    if (md) return resolveImage(md[1], post);
    const html = body.match(/<img[^>]*\ssrc="([^"]+)"/i);
    return html ? resolveImage(html[1], post) : '';
}

export function plainText(post: Post): string {
    return (post.body || '')
        .replace(/```[\s\S]*?```/g, ' ')
        .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
        .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
        .replace(/^[#>\-*]+\s*/gm, '')
        .replace(/[<>`*_|]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function tally(items: string[]): Term[] {
    const counts = new Map<string, number>();
    for (const item of items) counts.set(item, (counts.get(item) || 0) + 1);
    return [...counts.entries()]
        .map(([name, count]) => ({ name, slug: slugFor(name), count }))
        .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, 'zh'));
}


export function categoriesOf(post: Post): string[] {
    const raw = post.data.category;
    return Array.isArray(raw) ? raw : [raw];
}

export async function getTaxonomies() {
    const posts = await getPosts();
    const categories = tally(posts.flatMap((p) => categoriesOf(p)));
    const tags = tally(posts.flatMap((p) => p.data.tags));
    const years = tally(posts.map((p) => String(p.data.date.getUTCFullYear())))
        .sort((a, b) => b.name.localeCompare(a.name));
    return { categories, tags, years };
}

export function postsOfCategory(posts: Post[], name: string): Post[] {
    return posts.filter((p) => categoriesOf(p).includes(name));
}

export function postsOfTag(posts: Post[], name: string): Post[] {
    return posts.filter((p) => p.data.tags.includes(name));
}

export function postsOfYear(posts: Post[], year: string): Post[] {
    return posts.filter((p) => String(p.data.date.getUTCFullYear()) === year);
}
