const WEEKS = ['日', '一', '二', '三', '四', '五', '六'];
const MAPS = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
const UNITS = ['', '十', '百'];
const TZ_SHIFT = 8 * 3600 * 1000;
const DAY = 86400000;
const WEEK = 7 * DAY;

function shifted(ts: number): Date {
    return new Date(ts + TZ_SHIFT);
}

function dayStart(ts: number): number {
    const d = shifted(ts);
    return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) - TZ_SHIFT;
}

function chineseNumeral(num: number): string {
    const rev = String(num).split('').reverse();
    let ret = '';
    for (let i = rev.length - 1; i >= 0; i--) {
        const n = Number(rev[i]);
        if (n) {
            ret += (num >= 20 || i !== 1 ? MAPS[n] : '') + (UNITS[i] ?? '');
        } else if (i > 0 && Number(rev[i - 1]) !== 0) {
            ret += '零';
        }
    }
    return ret;
}

function informal(num: number): string {
    const s = chineseNumeral(num);
    return s === '二' ? '两' : s;
}

export function timePeriod(date: Date): string {
    const h = shifted(date.getTime()).getUTCHours();
    if (h >= 23 || h < 1) return '午夜';
    if (h < 3) return '凌晨';
    if (h < 5) return '黎明';
    if (h < 7) return '清晨';
    if (h < 9) return '早晨';
    if (h < 11) return '上午';
    if (h < 13) return '中午';
    if (h < 15) return '午后';
    if (h < 17) return '下午';
    if (h < 19) return '傍晚';
    if (h < 21) return '晚上';
    return '深夜';
}

export function relativeTime(date: Date, now: Date = new Date()): string {
    const ts = date.getTime();
    const nowTs = now.getTime();
    const diff = Math.floor((nowTs - ts) / 1000);
    if (diff < 60) return '刚刚';
    if (diff < 1800) return informal(Math.floor(diff / 60)) + '分钟前';
    if (diff < 3600) return '半小时前';
    if (diff < 86400) return informal(Math.floor(diff / 3600)) + '小时前';

    const todayStart = dayStart(nowTs);
    const targetStart = dayStart(ts);
    const diffDays = todayStart - targetStart;
    if (diffDays === DAY) return '昨天';
    if (diffDays === 2 * DAY) return '前天';

    const n = shifted(nowTs);
    const t = shifted(ts);
    const weekOffset = n.getUTCDay() || 7;
    const weekStart = todayStart - DAY * weekOffset;
    if (weekStart <= targetStart) return '周' + WEEKS[t.getUTCDay()];
    if (weekStart - WEEK <= targetStart) return '上周' + WEEKS[t.getUTCDay()];
    if (todayStart - DAY * (21 + weekOffset) <= targetStart) {
        return informal(Math.floor((nowTs - targetStart) / WEEK)) + '周前';
    }

    const lastMonthStart = Date.UTC(n.getUTCFullYear(), n.getUTCMonth() - 1, 1) - TZ_SHIFT;
    if (lastMonthStart <= targetStart) return '上个月';

    const yearStart = Date.UTC(n.getUTCFullYear(), 0, 1) - TZ_SHIFT;
    if (yearStart <= targetStart) {
        const months = n.getUTCMonth() - t.getUTCMonth() - (t.getUTCDate() > n.getUTCDate() ? 1 : 0);
        return informal(Math.max(0, months)) + '个月前';
    }

    const lastYearStart = Date.UTC(n.getUTCFullYear() - 1, 0, 1) - TZ_SHIFT;
    if (lastYearStart <= targetStart) return '去年';
    const beforeLastYearStart = Date.UTC(n.getUTCFullYear() - 2, 0, 1) - TZ_SHIFT;
    if (beforeLastYearStart <= targetStart) return '前年';

    const tMonth = t.getUTCMonth() + 1;
    const nMonth = n.getUTCMonth() + 1;
    const years = n.getUTCFullYear() - t.getUTCFullYear()
        - (30 * tMonth + t.getUTCDate() > 30 * nMonth + n.getUTCDate() ? 1 : 0);
    return informal(Math.max(1, years)) + '年前';
}

export function chineseTime(date: Date, now: Date = new Date()): string {
    const period = timePeriod(date);
    const t = shifted(date.getTime());
    const n = shifted(now.getTime());
    if (t.getUTCFullYear() === n.getUTCFullYear()
        && t.getUTCMonth() === n.getUTCMonth()
        && t.getUTCDate() === n.getUTCDate()) {
        return period;
    }
    const dateText = t.getUTCFullYear() === n.getUTCFullYear()
        ? `${t.getUTCMonth() + 1} 月 ${t.getUTCDate()} 日`
        : `${t.getUTCFullYear()} 年 ${t.getUTCMonth() + 1} 月 ${t.getUTCDate()} 日`;
    return `${dateText} ${period}`;
}

export function pageDate(date: Date): string {
    const d = shifted(date.getTime());
    return `${d.getUTCFullYear()} 年 ${d.getUTCMonth() + 1} 月 ${d.getUTCDate()} 日`;
}

export function isoDate(date: Date): string {
    return date.toISOString().slice(0, 10);
}
