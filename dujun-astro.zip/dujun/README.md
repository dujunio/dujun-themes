# dujun · Astro 静态版主题

极简、中文、自适应的博客主题 dujun 的 Astro 7.4 静态实现。无后端、无评论系统，构建出纯静态文件，部署到任意静态托管或 nginx。

## 环境要求

- Node.js `>= 22.23.4`（见 `package.json` 的 `engines`）
- npm（随 Node 一起安装）
- 本地预览或部署需要能启动静态服务；nginx 部署时把 `root` 指向 `dist/`

不需要数据库、不需要 PHP、不需要后台。

## 从零部署

下面假设你拿到的是 `dujun-astro.zip`，解压后目录名为 `dujun/`。

### 1. 解压并安装依赖

```sh
unzip dujun-astro.zip
cd dujun
npm ci          # 按 package-lock.json 精确安装；也可 npm install
```

### 2. 准备文章

主题包自带一篇示例文章 `src/content/blog/markdown.md`（Markdown 元素全家福，含表格 / 任务列表 / 脚注 / 代码块 / 图片）。它的 `category` 同时列入「随笔 / 照片 / 文章 / 作品」四个分类，因此只带一篇也能让顶部导航的四个分类全部出现。frontmatter 的 `category` 既支持单个字符串，也支持数组（`category: ['随笔', '照片']`），一篇文章可以归入多个分类。你自己发布时把它删掉或替换即可。

文章放在 `src/content/blog/`，每篇一个 `.md` 文件，文件名即 URL 的 slug（如 `hello.md` → `/blog/hello/`）。目录不存在就创建：

```sh
mkdir -p src/content/blog
```

每篇文章的 frontmatter 必须是这五个字段（`src/content.config.ts` 的 schema 强校验）：

```markdown
---
title: '文章标题'
date: 2026-11-16
description: '文章摘要，用于列表页与搜索结果'
category: '随笔'
tags: ['标签一', '标签二']
---

正文从这里开始，支持标准 Markdown 与 GFM（表格、任务列表、删除线、脚注）。
```

- `category` 决定文章归属哪个分类页（可写单值 `'随笔'` 或数组 `['随笔', '照片']` 归入多类）；分类页由所有文章的 `category` 自动生成
- `tags` 决定标签页
- `date` 的年份决定按年归档页
- `description` 同时作为搜索摘要

正文中的第一张图片会自动作为列表/搜索结果的封面。图片放在文章同目录（内容目录里）即可，用相对路径引用：

```markdown
![说明](./photo.jpg)
```

Astro 会把内容目录里的图片作为 asset 处理（正文输出优化后的 WebP，封面用原图 URL），无需放到 `public/`。封面解析由 `src/lib/posts.ts` 的 `contentImages` 映射完成；新增图片不需要改代码。

### 3. 修改站点配置

打开 `src/config.ts`：

```ts
export const SITE_TITLE = 'Dujun Theme';      // 站名，显示在页头/页脚/title
export const SITE_URL = 'https://example.com'; // 改成你的域名（canonical 与 RSS 用）
```

同文件里的 `config` 对象还能改：

| 项 | 说明 |
|---|---|
| `sitenameFont` | 页头站名字体，默认隶书；设 `'default'` 跟随主题 |
| `dark` | `'auto'` / `'light'` / `'dark'` |
| `sidebarTag` / `sidebarArchive` | 侧栏标签/归档开关 |
| `icpNumber` / `policeNumber` / `footerText` | 备案号与页脚附言 |
| `nav` | 顶部导航的分类文案与顺序 |
| `postsPerPage` | 每页文章数，默认 10 |

首页导航的分类顺序由 `nav` 显式声明，同时要保证文章里确实有这些 `category` 值，否则对应导航项不会出现。

### 4. 本地预览（可选）

```sh
npm run dev       # http://localhost:4321
npm run build     # 生成 dist/
npm run preview   # 预览构建产物
```

### 5. 构建并部署

```sh
npm run build
```

产物在 `dist/`，是纯静态文件。部署时把 web 服务器的根目录指向 `dist/`。nginx 示例：

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /path/to/dujun/dist;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    error_page 404 /404.html;
    location = /404.html { internal; }
}
```

其他静态托管（GitHub Pages、Netlify、Vercel、对象存储静态网站）直接把 `dist/` 上传/发布即可，构建命令 `npm run build`、输出目录 `dist`。

每次修改文章或配置后，重新 `npm run build` 并更新 `dist/` 即完成发布；不需要重启任何服务。

## 目录结构

```text
dujun/
├── src/
│   ├── config.ts          # 站点信息与主题设置（改这里）
│   ├── content.config.ts  # 文章 frontmatter 的 schema
│   ├── content/blog/      # 你的文章（需自行创建）
│   ├── components/        # 页头/页脚/侧栏/卡片/分页等
│   ├── layouts/           # 基础布局、文章页、404 页
│   ├── lib/               # 时间/文章聚合/分页算法
│   └── pages/             # 首页、文章、分类、标签、归档、搜索、RSS、404
├── public/
│   ├── assets/css/        # main.css 末尾含 Astro 适配层
│   ├── assets/js/         # main.js 末尾含 Astro 适配层
│   └── images/            # 图片（示例图可删）
├── astro.config.mjs       # Astro 配置（已启用 GFM 与脚注）
├── package.json
└── dist/                  # 构建产物（部署这个目录）
```

## 注意事项

- **没有评论系统**：静态站无后端，主题不输出任何评论 DOM 与交互。
- **文章不在包里**：请用自己的文章填充 `src/content/blog/`；空目录也能构建，但只有导航壳页面。
- **站名与字体**：`config.ts` 的 `SITE_TITLE` 与 `sitenameFont`，改完重新构建。
- **图片缩放**：正文图片会按横图 676px / 竖图 450px 自动限宽，点击可放大（桌面铺满视口，移动端双指缩放）。
- **资源版本**：`main.css` / `main.js` 带内容指纹，改动后普通刷新浏览器即可拿到新版本，无需手动清缓存。
