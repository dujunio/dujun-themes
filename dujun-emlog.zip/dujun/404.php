<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<?php require_once View::getView('module'); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover,user-scalable=no,shrink-to-fit=no">
    <meta name="renderer" content="webkit">
    <title>404 - 页面不存在 - <?php echo dj_e(Option::get('blogname')); ?></title>
    <link rel="stylesheet" href="<?php echo dj_asset('css/main.css'); ?>">
    <link rel="stylesheet" href="<?php echo dj_asset('css/error.css'); ?>">
</head>
<body class="error-body">
<div class="error-main">
    <div class="error-container">
        <header class="clearfix">
            <div class="error-title">404</div>
        </header>
        <section>
            <div class="error-text"><p>雷霆雨露　俱是天恩</p></div>
            <a class="index error-button" href="<?php echo BLOG_URL; ?>">前往首页</a>
        </section>
        <footer class="error-footer">&copy; <?php echo date('Y'); ?> <?php echo dj_e(Option::get('blogname')); ?>.</footer>
    </div>
</div>
</body>
</html>
