<?php
/*
Template Name: 杜郎俊赏
Version: 1.0.0
Template Url: https://dujun.io
Description: 一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。
Author: dujun
Author Url: https://dujun.io
*/

 defined('EMLOG_ROOT') || exit('access denied!'); require_once View::getView('module'); if (isset($_GET['s']) && !isset($_GET['keyword'])) { $q = trim((string)$_GET['s']); if ('' !== $q) { header('Location: ' . BLOG_URL . '?keyword=' . rawurlencode($q) . '&search=' . rawurlencode($q), true, 302); exit; } } $GLOBALS['dj_site_title'] = (string)($site_title ?? ''); $GLOBALS['dj_blogname'] = (string)($blogname ?? ''); $GLOBALS['dj_record'] = (string)($record ?? $_GET['record'] ?? ''); $djDarkClass = dj_html_dark_class(); $djNavCats = dj_nav_categories(); $djNavCategory = ''; if (!empty($sortid)) { foreach ($djNavCats as $djCat) { if ($djCat['id'] === (int)$sortid) { $djNavCategory = (string)$djCat['id']; break; } } } $djKeyword = dj_search_keyword(); $djOnSearch = isset($_GET['search']) || '' !== $djKeyword; if ('' !== $djKeyword) { $djTitle = '搜索「' . $djKeyword . '」 - ' . $blogname; } elseif ('' !== $GLOBALS['dj_record']) { $djTitle = dj_record_label($GLOBALS['dj_record']) . ' - ' . $blogname; } else { $djTitle = '' !== dj_clean_site_title() ? dj_clean_site_title() : $blogname; } ?>
<!DOCTYPE html>
<html lang="zh-CN"<?php echo $djDarkClass; ?>>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover,user-scalable=no,shrink-to-fit=no">
    <meta name="HandheldFriendly" content="true">
    <meta name="format-detection" content="telephone=no,email=no">
    <meta name="renderer" content="webkit">
    <title><?php echo dj_e($djTitle); ?></title>
    <link rel="alternate" title="RSS" href="<?php echo BLOG_URL; ?>rss.php" type="application/rss+xml">
    <link rel="stylesheet" href="<?php echo dj_asset('css/main.css'); ?>">
    <?php  ?>
    <link rel="stylesheet" href="<?php echo dj_asset('css/article.css'); ?>">
    <?php if ('' !== ($djFont = dj_sitename_font_stack())): ?>
        <style>.sitename a{font-family:<?php echo $djFont; ?>}</style>
    <?php endif; ?>
    <?php doAction('index_head'); ?>
</head>
<body>
<header class="header clearfix">
    <div class="container">
        <div class="column-group">
            <div class="sitename">
                <a class="index" href="<?php echo BLOG_URL; ?>"><?php echo dj_e($blogname); ?></a>
            </div>
            <div>
                
                <nav class="clearfix"><a class="content nav-search<?php echo $djOnSearch ? ' active' : ''; ?>" href="<?php echo dj_search_page_url(); ?>">搜索</a><?php foreach ($djNavCats as $djCat): ?><a class="archive<?php echo isset($sortid) && (int)$sortid === $djCat['id'] ? ' active' : ''; ?>" data-dj-category="<?php echo $djCat['id']; ?>" href="<?php echo dj_e($djCat['url']); ?>"><?php echo dj_e($djCat['name']); ?></a><?php endforeach; ?></nav>
            </div>
        </div>
    </div>
</header>
<div class="container">
    <div class="column-group">
        <div class="main">
            <div class="rescale-container" id="pjax-container"><?php if ('' !== $djNavCategory): ?><div hidden id="dj-nav-state" data-dj-category="<?php echo dj_e($djNavCategory); ?>"></div><?php endif; ?>
