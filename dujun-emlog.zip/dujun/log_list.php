<?php
defined('EMLOG_ROOT') || exit('access denied!'); $keyword = (string)($keyword ?? ''); $djSearchLanding = isset($_GET['search']) && '' === dj_search_keyword(); if ($djSearchLanding): ?>
    <section class="widget search">
        <form method="get" action="<?php echo BLOG_URL; ?>">
            <input type="text" name="s" class="search-input" placeholder="输入关键词" autocomplete="on" autofocus>
            <input type="hidden" name="keyword" value="">
            <?php echo dj_icon('search'); ?>
        </form>
    </section>
    <div class="sidebar nav-sidebar">
        <?php include TEMPLATE_PATH . 'parts/sidebar-widgets.php'; ?>
    </div>
    <?php include View::getView('footer'); return; ?>
<?php endif; $GLOBALS['dj_record'] = (string)($record ?? ''); $GLOBALS['dj_lognum'] = (int)($lognum ?? 0); $djIsHome = '' === $keyword && empty($sortid) && empty($tag) && empty($record) && empty($author); if (!$djIsHome) { include TEMPLATE_PATH . 'parts/archive-title.php'; } $Log_Model = new Log_Model(); foreach ((array)$logs as $value): $djUrl = (string)($value['log_url'] ?? Url::log($value['logid'])); $djHtml = (string)($value['log_description'] ?? ''); $djDetail = $Log_Model->getOneLogForHome((int)($value['logid'] ?? 0)); $djCover = dj_first_image((string)($djDetail['log_content'] ?? '')); if ('' === $djCover && !empty($value['log_cover'])) { $djCover = (string)$value['log_cover']; } if ('' !== $djCover) { $djCover = dj_https(dj_cover_url($djCover)); } $djExcerpt = dj_strip_md_syntax(strip_tags(subContent($djHtml, 180, 1))); if ('' !== $keyword) { $djExcerpt = dj_highlight($djExcerpt, $keyword); $djTitle = dj_highlight(dj_e($value['log_title']), $keyword); } else { $djTitle = dj_e($value['log_title']); } ?>
    <article>
        <h2 class="article-title"><a class="content" href="<?php echo dj_e($djUrl); ?>"><?php echo $djTitle; ?></a></h2>
        <div>
            <?php if ('' !== $djCover): ?>
                <a class="content" href="<?php echo dj_e($djUrl); ?>">
                    <div class="summary-cover">
                        <div class="summary-cover-inner"><img src="<?php echo dj_e($djCover); ?>" alt="" loading="lazy"></div>
                    </div>
                </a>
            <?php endif; ?>
            <div class="summary-text-inner">
                <a class="content" href="<?php echo dj_e($djUrl); ?>"><?php echo $djExcerpt; ?></a>
            </div>
        </div>
        <div class="article-meta clearfix">
            <span><?php echo dj_relative_time((int)($value['date'] ?? time())); ?></span>
            <?php if (($value['comnum'] ?? 0) > 0): ?>
                ｜ <a class="content" href="<?php echo dj_e($djUrl); ?>#comment"><?php echo (int)$value['comnum']; ?> 评论</a>
            <?php endif; ?>
        </div>
    </article>
<?php endforeach; $djPageUrl = (string)($pageurl ?? Url::logPage()); if (isset($_GET['keyword'])) { $djPageUrl = BLOG_URL . '?keyword=' . rawurlencode(dj_search_keyword()) . '&search=' . rawurlencode(dj_search_keyword()) . '&page='; } dj_page_nav((int)($lognum ?? 0), (int)($index_lognum ?? 10), (int)($page ?? 1), $djPageUrl); include View::getView('footer'); 