<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<article id="content">
    <h1 class="article-title"><?php echo dj_e($log_title); ?></h1>
    <div class="article-content"><?php
 echo dj_content_tasks(dj_content_images(dj_https((string)$log_content))); ?></div>
    <div class="article-meta clearfix">
        <span><?php echo dj_site_date('Y 年 m 月 d 日', (int)$date); ?></span>
        <?php if (ISLOGIN): ?>
            ｜ <a class="content" href="<?php echo BLOG_URL; ?>admin/page.php?action=edit&id=<?php echo (int)$logid; ?>" target="_blank" rel="noopener">编辑</a>
        <?php endif; ?>
    </div>
</article>
<?php include View::getView('comments'); ?>
<?php include View::getView('footer'); ?>
