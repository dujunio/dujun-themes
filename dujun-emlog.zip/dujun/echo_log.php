<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<article id="content">
    <h1 class="article-title"><?php echo dj_e($log_title); ?></h1>
    <div class="article-content"><?php
 echo dj_content_tasks(dj_content_images(dj_content_links(dj_https((string)$log_content)))); ?></div>
    <?php
 $tagModel = new Tag_Model(); $tagNames = $tagModel->getNamesFromIds($tagModel->getTagIdsFromBlogId((int)$logid)); if (!empty($tagNames)): ?>
        <div class="article-tag">
            <?php foreach ($tagNames as $tagName): ?>
                <a href="<?php echo dj_e(Url::tag(rawurlencode((string)$tagName))); ?>"><?php echo dj_e($tagName); ?></a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <div class="article-meta clearfix">
        <span><?php echo dj_chinese_time((int)$date); ?></span>
        <?php if (ISLOGIN): ?>
            ｜ <a class="content" href="<?php echo BLOG_URL; ?>admin/article.php?action=edit&id=<?php echo (int)$logid; ?>" target="_blank" rel="noopener">编辑</a>
        <?php endif; ?>
    </div>
</article>
<?php include View::getView('comments'); ?>
<?php include View::getView('footer'); ?>
