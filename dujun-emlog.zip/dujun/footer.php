<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
</div>
</div>
<?php include View::getView('side'); ?>
</div>
</div>
<footer class="footer">
    <div class="container">
        <span class="footer-line">&copy; <?php echo date('Y'); ?> <?php echo dj_e($blogname); ?>.</span>
        <span class="footer-line">Powered by <a href="https://www.emlog.net" target="_blank" rel="nofollow" style="margin-right:0">emlog</a>. Theme by <a href="https://dujun.io" target="_blank" rel="nofollow" style="margin-right:0">dujun</a>.</span>
        <?php
 $extras = []; $icp = dj_em('icpNumber', (string)Option::get('icp')); $police = dj_em('policeNumber'); $footerText = dj_em('footerText'); if ('' !== $icp) { $extras[] = '<a class="footer-beian" href="https://beian.miit.gov.cn" target="_blank" rel="nofollow" style="margin-right:0">' . dj_e($icp) . '</a>'; } if ('' !== $police) { $extras[] = '<a class="footer-beian" href="https://www.beian.gov.cn" target="_blank" rel="nofollow" style="margin-right:0">' . dj_e($police) . '</a>'; } if ('' !== $footerText) { $extras[] = dj_e($footerText); } if (count($extras)) { echo '<span class="footer-line">' . implode('. ', $extras) . '.</span>'; } ?>
    </div>
</footer>
<script src="<?php echo dj_asset('js/main.js'); ?>"></script>
<script src="<?php echo dj_asset('js/article.js'); ?>"></script>
<?php doAction('index_footer'); ?>
</body>
</html>
