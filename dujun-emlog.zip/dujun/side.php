<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<div class="sidebar">
    <section class="widget search">
        <form method="get" action="<?php echo BLOG_URL; ?>">
            <input type="text" name="s" class="search-input" placeholder="输入关键词" autocomplete="on">
            <input type="hidden" name="keyword" value="">
            <?php echo dj_icon('search'); ?>
        </form>
    </section>
    <?php include TEMPLATE_PATH . 'parts/sidebar-widgets.php'; ?>
</div>
