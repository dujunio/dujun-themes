<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<?php [$djTitle, $djTotal] = dj_archive_meta(); ?>
<h3 class="archive-title"><?php echo dj_e($djTitle); ?> <em><?php echo $djTotal; ?></em> 篇</h3>
