<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<?php dj_sidebar_widgets(); ?>
