<?php defined('EMLOG_ROOT') || exit('access denied!'); ?>
<div id="comment">
    <?php dj_render_comments((array)$comments, $comnum ?? 0); ?>
    <?php dj_render_comment_form((int)$logid, (string)($ckname ?? ''), (string)($ckmail ?? ''), (string)($ckurl ?? ''), (string)($verifyCode ?? ''), (string)($allow_remark ?? 'y')); ?>
</div>
