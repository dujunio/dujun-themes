# frozen_string_literal: true

require "fileutils"
require "json"
require "time"

module Dujun
  TZ_SHIFT = 8 * 3600
  DAY = 86_400
  WEEK = 7 * DAY
  WEEKS = %w[日 一 二 三 四 五 六].freeze
  MAPS = %w[零 一 二 三 四 五 六 七 八 九].freeze
  UNITS = ["", "十", "百"].freeze

  SLUGS = {
    "技术笔记" => "notes",
    "日常随笔" => "essays",
    "搜索" => "search",
    "占位" => "placeholder",
    "照片" => "photos",
    "文章" => "articles",
    "作品" => "works",
    "随笔" => "essay",
    "排版" => "typography",
    "test" => "test",
  }.freeze

  module_function

  def to_time(value)
    return value.utc if value.is_a?(Time)
    return value.to_time.utc if value.respond_to?(:to_time)
    Time.parse(value.to_s).utc
  rescue ArgumentError
    Time.at(0).utc
  end

  def shifted(time)
    to_time(time) + TZ_SHIFT
  end

  def day_start(timestamp)
    d = Time.at(timestamp + TZ_SHIFT).utc
    Time.utc(d.year, d.month, d.day).to_i - TZ_SHIFT
  end

  def chinese_numeral(num)
    rev = num.to_s.chars.reverse
    ret = +""
    (rev.length - 1).downto(0) do |i|
      n = rev[i].to_i
      if n != 0
        ret << (num >= 20 || i != 1 ? MAPS[n] : "") << (UNITS[i] || "")
      elsif i > 0 && rev[i - 1].to_i != 0
        ret << "零"
      end
    end
    ret
  end

  def informal(num)
    value = chinese_numeral(num)
    value == "二" ? "两" : value
  end

  def time_period(time)
    hour = shifted(time).hour
    return "午夜" if hour >= 23 || hour < 1
    return "凌晨" if hour < 3
    return "黎明" if hour < 5
    return "清晨" if hour < 7
    return "早晨" if hour < 9
    return "上午" if hour < 11
    return "中午" if hour < 13
    return "午后" if hour < 15
    return "下午" if hour < 17
    return "傍晚" if hour < 19
    return "晚上" if hour < 21
    "深夜"
  end

  def relative_time(time, now = Time.now.utc)
    ts = to_time(time).to_i
    now_ts = to_time(now).to_i
    diff = now_ts - ts
    return "刚刚" if diff < 60
    return "#{informal(diff / 60)}分钟前" if diff < 1800
    return "半小时前" if diff < 3600
    return "#{informal(diff / 3600)}小时前" if diff < DAY

    today_start = day_start(now_ts)
    target_start = day_start(ts)
    diff_days = today_start - target_start
    return "昨天" if diff_days == DAY
    return "前天" if diff_days == 2 * DAY

    n = Time.at(now_ts + TZ_SHIFT).utc
    t = Time.at(ts + TZ_SHIFT).utc
    week_offset = n.wday.zero? ? 7 : n.wday
    week_start = today_start - DAY * week_offset
    return "周#{WEEKS[t.wday]}" if week_start <= target_start
    return "上周#{WEEKS[t.wday]}" if week_start - WEEK <= target_start
    if today_start - DAY * (21 + week_offset) <= target_start
      return "#{informal((now_ts - target_start) / WEEK)}周前"
    end

    last_month_start = Time.utc(n.year, n.month - 1, 1).to_i - TZ_SHIFT
    return "上个月" if last_month_start <= target_start

    year_start = Time.utc(n.year, 1, 1).to_i - TZ_SHIFT
    if year_start <= target_start
      months = n.month - t.month - (t.day > n.day ? 1 : 0)
      return "#{informal([months, 0].max)}个月前"
    end

    last_year_start = Time.utc(n.year - 1, 1, 1).to_i - TZ_SHIFT
    return "去年" if last_year_start <= target_start
    before_last_year_start = Time.utc(n.year - 2, 1, 1).to_i - TZ_SHIFT
    return "前年" if before_last_year_start <= target_start

    years = n.year - t.year - ((30 * t.month + t.day) > (30 * n.month + n.day) ? 1 : 0)
    "#{informal([years, 1].max)}年前"
  end

  def chinese_time(time, now = Time.now.utc)
    period = time_period(time)
    t = shifted(time)
    n = shifted(now)
    if t.year == n.year && t.month == n.month && t.day == n.day
      return period
    end
    date_text = if t.year == n.year
                  "#{t.month} 月 #{t.day} 日"
                else
                  "#{t.year} 年 #{t.month} 月 #{t.day} 日"
                end
    "#{date_text} #{period}"
  end

  def page_date(time)
    d = shifted(time)
    "#{d.year} 年 #{d.month} 月 #{d.day} 日"
  end

  def iso_date(time)
    to_time(time).strftime("%Y-%m-%d")
  end

  def rss_date(time)
    to_time(time).strftime("%a, %d %b %Y %H:%M:%S GMT")
  end

  def slug_for(name)
    text = name.to_s
    return SLUGS[text] if SLUGS.key?(text)
    ascii = text.downcase.gsub(/[^a-z0-9]+/, "-").gsub(/\A-|-\z/, "")
    ascii.empty? ? "item" : ascii
  end

  def excerpt(text, limit = 180)
    value = text.to_s
    value.length > limit ? "#{value[0, limit]}……" : value
  end

  def plain_text(body)
    body.to_s
        .gsub(/```[\s\S]*?```/, " ")
        .gsub(/!\[[^\]]*\]\([^)]*\)/, " ")
        .gsub(/\[([^\]]*)\]\([^)]*\)/, '\1')
        .gsub(/^[#>\-*]+\s*/, "")
        .gsub(/[<>`*_|]/, " ")
        .gsub(/\s+/, " ")
        .strip
  end

  def cover(body)
    value = body.to_s
    md = value.match(/!\[[^\]]*\]\(([^)\s]+)/)
    return md[1] if md
    html = value.match(/<img[^>]*\ssrc="([^"]+)"/i)
    html ? html[1] : ""
  end

  def highlight(text, keyword)
    value = text.to_s
    return value if keyword.to_s.empty?
    value.gsub(/(#{Regexp.escape(keyword.to_s)})/i, "<em>\\1</em>")
  end

  def cdata(value)
    "<![CDATA[#{value.to_s.gsub("]]>", "]]]]><![CDATA[>")}]]>"
  end

  def page_items(current, total)
    return [] if total < 2

    split = 2
    if total < 9
      split = 9
    elsif current < 4
      split = 5 - current
    elsif total - 4 < current
      split = 5 + current - total
    end
    from = [1, current - split].max
    to = [total, current + split].min
    items = []
    items << { "kind" => "prev", "page" => current - 1 } if current > 1
    if from > 1
      items << { "kind" => "first", "page" => 1 }
      items << { "kind" => "delimiter" } if from > 2
    end
    (from..to).each do |page|
      items << { "kind" => "page", "page" => page, "active" => page == current }
    end
    if to < total
      items << { "kind" => "delimiter" } if to < total - 1
      items << { "kind" => "last", "page" => total }
    end
    items << { "kind" => "next", "page" => current + 1 } if current < total
    items
  end

  def page_url(page, base = "/")
    root = base == "/" ? "" : base.to_s.sub(%r{/$}, "")
    page.to_i <= 1 ? (root.empty? ? "/" : root) : "#{root}/page/#{page}/"
  end

  def total_pages(count, per_page)
    [1, (count.to_f / per_page).ceil].max
  end

  def paginate(items, page, per_page)
    items.slice((page - 1) * per_page, per_page) || []
  end

  def tally(items)
    counts = Hash.new(0)
    items.each { |item| counts[item.to_s] += 1 }
    counts.map do |name, count|
      { "name" => name, "slug" => slug_for(name), "count" => count }
    end.sort_by { |term| [-term["count"], term["name"]] }
  end
end

module DujunFilters
  def dj_relative_time(input)
    Dujun.relative_time(Dujun.to_time(input))
  end

  def dj_chinese_time(input)
    Dujun.chinese_time(Dujun.to_time(input))
  end

  def dj_page_date(input)
    Dujun.page_date(Dujun.to_time(input))
  end

  def dj_date_iso(input)
    Dujun.iso_date(Dujun.to_time(input))
  end

  def dj_year(input)
    Dujun.shifted(Dujun.to_time(input)).year.to_s
  end

  def dj_slug(input)
    Dujun.slug_for(input)
  end

  def dj_excerpt(input, limit = 180)
    Dujun.excerpt(input, limit.to_i)
  end

  def dj_plain_text(input)
    Dujun.plain_text(input)
  end

  def dj_cover(input)
    Dujun.cover(input)
  end

  def dj_highlight(input, keyword = "")
    Dujun.highlight(input, keyword)
  end

  def dj_page_items(current, total)
    Dujun.page_items(current.to_i, total.to_i)
  end

  def dj_page_url(page, base = "/")
    Dujun.page_url(page, base)
  end

  def dj_content(input)
    html = input.to_s
                .gsub('<ul class="task-list">', '<ul class="contains-task-list">')
                .gsub('class="task-list-item-checkbox" ', '')
                .gsub('<code class="language-plaintext highlighter-rouge">', '<code>')
    html = html.gsub(%r{<div class="language-([a-z0-9_+-]+) highlighter-rouge"><div class="highlight"><pre class="highlight"><code>(.*?)</code></pre></div></div>}m) do
      language = Regexp.last_match(1)
      code = Regexp.last_match(2).gsub(%r{<span[^>]*>}, "").gsub("</span>", "")
      "<pre><code class=\"language-#{language}\">#{code}</code></pre>"
    end
    html = html.gsub(%r{<sup id="fnref:([^"]+)"><a href="#fn:\1" class="footnote" rel="footnote" role="doc-noteref">([^<]*)</a></sup>}) do
      key = Regexp.last_match(1)
      "<sup><a href=\"#user-content-fn-#{key}\" id=\"user-content-fnref-#{key}\" data-footnote-ref=\"\" aria-describedby=\"footnote-label\">#{Regexp.last_match(2)}</a></sup>"
    end
    html.gsub(%r{<div class="footnotes" role="doc-endnotes">(.*?)</div>}m) do
      inner = Regexp.last_match(1)
                    .gsub("<ol>", "<h2 class=\"sr-only\" id=\"footnote-label\">Footnotes</h2><ol>")
                    .gsub(/id="fn:([^"]+)"/, 'id="user-content-fn-\1"')
                    .gsub(/href="#fnref:([^"]+)"/, 'href="#user-content-fnref-\1"')
                    .gsub('class="reversefootnote" role="doc-backlink"', 'data-footnote-backref="" aria-label="Back to reference" class="data-footnote-backref"')
                    .gsub("&#8617;", "↩")
      "<section data-footnotes=\"\" class=\"footnotes\">#{inner}</section>"
    end
  end
end

Liquid::Template.register_filter(DujunFilters)

class DujunGenerator < Jekyll::Generator
  def generate(site)
    posts = site.collections["blog"] ? site.collections["blog"].docs.dup : []
    posts.sort_by! { |doc| -Dujun.to_time(doc.data["date"] || doc.date).to_i }

    posts.each do |doc|
      time = Dujun.to_time(doc.data["date"] || doc.date)
      doc.data["dj_cover"] = Dujun.cover(doc.content)
      doc.data["dj_excerpt"] = Dujun.excerpt(doc.data["description"])
      doc.data["dj_plain_text"] = Dujun.plain_text(doc.content)
      doc.data["dj_time"] = Dujun.relative_time(time)
      doc.data["dj_chinese_time"] = Dujun.chinese_time(time)
      doc.data["dj_date_iso"] = Dujun.iso_date(time)
      doc.data["dj_year"] = Dujun.shifted(time).year.to_s
      doc.data["dj_categories"] = Array(doc.data["category"])
      doc.data["dj_tags"] = Array(doc.data["tags"])
      doc.data["nav_category"] = doc.data["dj_categories"].first
    end

    categories = Dujun.tally(posts.flat_map { |doc| doc.data["dj_categories"] })
    tags = Dujun.tally(posts.flat_map { |doc| doc.data["dj_tags"] })
    years = Dujun.tally(posts.map { |doc| doc.data["dj_year"] })
                 .sort_by { |term| [-term["name"].to_i] }

    site.data["dujun"] = {
      "categories" => categories,
      "tags" => tags,
      "years" => years,
    }

    per_page = [site.config["posts_per_page"].to_i, 1].max
    add_list_pages(site, posts, "/", "", nil, nil, per_page)
    categories.each do |term|
      add_list_pages(site, posts_of(posts, "category", term["name"]), "/category/#{term["slug"]}/",
                     "category/#{term["slug"]}", term["name"], term["name"], per_page, "category", term["name"])
    end
    tags.each do |term|
      add_list_pages(site, posts_of(posts, "tag", term["name"]), "/tag/#{term["slug"]}/",
                     "tag/#{term["slug"]}", term["name"], term["name"], per_page, "tag")
    end
    years.each do |term|
      add_list_pages(site, posts_of(posts, "year", term["name"]), "/archive/#{term["name"]}/",
                     "archive/#{term["name"]}", "#{term["name"]} 的存档", "#{term["name"]} 年", per_page, "year", term["name"])
    end

    add_data_page(site, "search-index.json", JSON.generate(posts.map { |doc|
      {
        "title" => doc.data["title"].to_s,
        "url" => doc.url,
        "description" => doc.data["description"].to_s,
        "excerpt" => doc.data["dj_excerpt"],
        "cover" => doc.data["dj_cover"],
        "category" => doc.data["category"],
        "tags" => doc.data["dj_tags"],
        "date" => Dujun.iso_date(doc.data["date"] || doc.date) + "T00:00:00.000Z",
        "time" => doc.data["dj_time"],
        "text" => doc.data["dj_plain_text"],
      }
    }))

    items = posts.map { |doc|
      link = "#{site.config["url"].to_s.sub(%r{/$}, "")}#{doc.url}"
      "<item><title>#{Dujun.cdata(doc.data["title"])}</title><link>#{link}</link><guid>#{link}</guid>" \
        "<pubDate>#{Dujun.rss_date(doc.data["date"] || doc.date)}</pubDate>" \
        "<description>#{Dujun.cdata(doc.data["description"])}</description></item>"
    }.join
    xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><rss version=\"2.0\"><channel>" \
          "<title>#{Dujun.cdata(site.config["title"])}</title>" \
          "<link>#{site.config["url"].to_s.sub(%r{/$}, "")}/</link>" \
          "<description>#{Dujun.cdata(site.config["theme_description"])}</description>#{items}</channel></rss>"
    add_data_page(site, "rss.xml", xml)
  end

  private

  def posts_of(posts, kind, name)
    posts.select do |doc|
      case kind
      when "category" then doc.data["dj_categories"].include?(name)
      when "tag" then doc.data["dj_tags"].include?(name)
      when "year" then doc.data["dj_year"] == name
      else true
      end
    end
  end

  def add_list_pages(site, list, base, dir, title, archive_title, per_page, kind = nil, nav_category = nil)
    total = Dujun.total_pages(list.length, per_page)
    (1..total).each do |page_number|
      current_dir = page_number == 1 ? dir : "#{dir}/page/#{page_number}"
      page_title = if title.nil? || title.empty?
                     page_number == 1 ? nil : "第 #{page_number} 页"
                   else
                     page_number == 1 ? title : "#{title} - 第 #{page_number} 页"
                   end
      add_page(site, current_dir, "index.html", "archive", {
        "title" => page_title,
        "posts" => Dujun.paginate(list, page_number, per_page),
        "current" => page_number,
        "total" => total,
        "count" => list.length,
        "base" => base,
        "archive_title" => archive_title,
        "pager_items" => Dujun.page_items(page_number, total),
        "category" => kind == "category" ? nav_category : nil,
      })
    end
  end

  def add_page(site, dir, name, layout, data)
    page = Jekyll::PageWithoutAFile.new(site, site.source, dir, name)
    page.data["layout"] = layout
    data.each { |key, value| page.data[key.to_s] = value }
    page.content = ""
    site.pages << page
  end

  def add_data_page(site, name, content)
    page = Jekyll::PageWithoutAFile.new(site, site.source, "", name)
    page.content = content
    site.pages << page
  end
end

# 文章配图属于内容目录；站名字体与暗色 cookie 在构建时写入 main.css / main.js，
# 模板不再输出内联 style/script。
Jekyll::Hooks.register :site, :post_write do |site|
  images = Dir[site.in_source_dir("_blog", "*.{jpg,jpeg,png,webp,gif,svg}")]
  unless images.empty?
    FileUtils.mkdir_p(site.in_dest_dir("assets", "img"))
    images.each do |image|
      FileUtils.cp(image, site.in_dest_dir("assets", "img", File.basename(image)))
    end
  end

  font = site.config["sitename_font"].to_s
  unless font.empty? || font == "default"
    css = site.in_dest_dir("assets", "css", "main.css")
    File.open(css, "a") { |file| file.write("\n.sitename a{font-family:#{font}}\n") } if File.exist?(css)
  end

  if site.config["dark"].to_s == "auto"
    js = site.in_dest_dir("assets", "js", "main.js")
    if File.exist?(js)
      File.open(js, "a") do |file|
        file.write("\n(function(){var m=document.cookie.match(/(?:^|;\\s*)dujun_dark=([01])/);if(m)document.documentElement.classList.add(m[1]==='1'?'dark':'light');})();\n")
      end
    end
  end
end
