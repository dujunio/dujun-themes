# dujun · Jekyll 主题

一款极简自适应主题，复刻了 dujun.io 的前端设计——干净、克制、阅读优先。

## 环境

- Jekyll 4.4.1 / Ruby 3.1+
- 不需要数据库，也不需要前端构建工具链

## 使用

1. 把本目录作为 Jekyll 站点根目录。
2. 编辑 `_config.yml`：修改 `title`、`url`（正式部署时改成自己的域名）、`sitename_font`、备案号与页脚附言、`dark`、`sidebar_tag`、`sidebar_archive`、`nav`、`posts_per_page`。
3. 把文章放进 `_blog/`，文件名即文章标识，访问路径为 `/blog/<文件名>/`。
4. 构建：`bundle install && bundle exec jekyll build`，输出目录为 `_site/`。
5. nginx 的 `root` 指向 `_site/` 即可；改动内容后重新构建。

## 文章 frontmatter

```yaml
---
title: 文章标题
date: 2026-11-22 08:00:00 +0800
description: 用于列表摘要、搜索索引与 RSS 的一段话
category: [随笔, 文章]
tags: [排版, 示例]
---
```

- `category` 可写单个字符串或数组；数组会同时归入多个分类。
- 封面从正文第一张图片自动推导，不设额外字段。
- 文章配图放在 `_blog/` 内容目录，构建时自动输出到 `/assets/img/`；正文可引用 `/assets/img/<文件名>`。
- 时间、摘要、封面与搜索索引都在构建期生成。

## 页面与路由

- 首页 `/`，分页 `/page/N/`
- 文章 `/blog/<文件名>/`
- 分类 `/category/<slug>/`、标签 `/tag/<slug>/`、按年归档 `/archive/<年份>/`，各自带 `/page/N/` 分页
- 搜索 `/search?search`（落地页）与 `/search?s=关键词`（结果页，前端检索 `search-index.json`）
- 关于 `/about/`、404 `/404.html`、RSS `/rss.xml`

中文分类与标签的 URL 映射集中在 `_plugins/dujun.rb` 的 `SLUGS`，需要新增词条时按现有格式补充。

## 说明

- 静态站点没有评论系统，模板不输出任何评论结构。
- 主题选项都在 `_config.yml`，改完重新构建即可生效。
- 主题仓库：https://github.com/dujunio/dujun-themes
