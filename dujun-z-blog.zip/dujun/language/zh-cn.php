<?php
return array( 'theme_name' => '杜郎俊赏', ); 