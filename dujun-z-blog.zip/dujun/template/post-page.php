{* Template Name:独立页正文 *}
{php} dujun_single_content($article, 'page'); {/php}
{template:comments}
