{* Template Name:文章正文 *}
{php} dujun_single_content($article, 'article'); {/php}
{template:comments}
