{* Template Name:评论列表及表单 *}
{php} dujun_render_comments($comments, $article, $pagebar); {/php}
