{* Template Name:站内搜索结果（Z-BlogPHP 原生 ?q= 路由） *}
{template:header}
{php} $dujunArticles = dujun_query_articles($articles); {/php}
{php} dujun_archive_title(dujun_page_label() !== '' ? dujun_page_label() : $title, dujun_total($pagebar, $dujunArticles)); {/php}
{foreach $dujunArticles as $article}
{template:post-multi}
{/foreach}
{php} dujun_page_nav($pagebar); {/php}
{template:footer}
