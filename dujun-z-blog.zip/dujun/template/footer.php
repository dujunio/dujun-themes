{* Template Name:公共底部 *}
</div>
</div>
{template:sidebar}
</div>
</div>
<footer class="footer">
  <div class="container">
    <span class="footer-line">&copy; {php} echo date('Y'); {/php} {$name}.</span>
    <span class="footer-line">Powered by <a href="https://www.zblogcn.com" target="_blank" rel="nofollow" style="margin-right:0">Z-BlogPHP</a>. Theme by <a href="https://dujun.io" target="_blank" rel="nofollow" style="margin-right:0">dujun</a>.</span>
{php} dujun_footer_extras(); {/php}
  </div>
</footer>
<script src="{php} echo dujun_asset('js/main.js'); {/php}"></script>
<script src="{php} echo dujun_asset('js/article.js'); {/php}"></script>
{$footer}
</body>
</html>
