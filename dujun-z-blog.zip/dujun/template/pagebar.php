{* Template Name:分页 *}
{php} dujun_page_nav($pagebar); {/php}
