{* Template Name:404 *}
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover,user-scalable=no,shrink-to-fit=no">
<meta name="renderer" content="webkit">
<title>404 - 页面不存在 - {$name}</title>
<link rel="stylesheet" href="{php} echo dujun_asset('css/main.css'); {/php}">
<link rel="stylesheet" href="{php} echo dujun_asset('css/error.css'); {/php}">
{$header}
</head>
<body class="error-body">
<div class="error-main">
  <div class="error-container">
    <header class="clearfix"><div class="error-title">404</div></header>
    <section>
      <div class="error-text"><p>雷霆雨露　俱是天恩</p></div>
      <a class="index error-button" href="{$host}">前往首页</a>
    </section>
    <footer class="error-footer">&copy; {php} echo date('Y'); {/php} {$name}.</footer>
  </div>
</div>
{$footer}
</body>
</html>
