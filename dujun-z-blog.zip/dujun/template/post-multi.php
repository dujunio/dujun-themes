{* Template Name:列表文章条目 *}
<article>
  <h2 class="article-title"><a class="content" href="{$article.Url}">{php} echo dujun_highlight(dujun_e($article->Title), dujun_search_keyword()); {/php}</a></h2>
  <div>
{php} echo dujun_cover_html($article); {/php}
    <div class="summary-text-inner"><a class="content" href="{$article.Url}">{php} echo dujun_intro_html($article); {/php}</a></div>
  </div>
  <div class="article-meta clearfix">
    <span>{php} echo dujun_relative_time($article->PostTime); {/php}</span>
    ｜ <a class="content" href="{$article.Url}#comment">{php} echo dujun_comment_num_label($article->CommNums); {/php}</a>
  </div>
</article>
