{* Template Name:侧栏 *}
<div class="sidebar">
{php} dujun_search_form(); {/php}
{template:sidebar-widgets}
</div>
