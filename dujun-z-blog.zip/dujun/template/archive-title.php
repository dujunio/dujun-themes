{* Template Name:归档标题 *}
{php} dujun_archive_title($title, dujun_total($pagebar, $articles)); {/php}
