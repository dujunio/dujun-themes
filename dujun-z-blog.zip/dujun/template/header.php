{* Template Name:公共头部 *}
<!DOCTYPE html>
<html lang="zh-CN" class="han-init{php} echo dujun_dark_class(); {/php}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover,user-scalable=no,shrink-to-fit=no">
<meta name="HandheldFriendly" content="true">
<meta name="format-detection" content="telephone=no,email=no">
<meta name="renderer" content="webkit">
<title>{php} echo dujun_title($title, $name, $type); {/php}</title>
<link rel="stylesheet" href="{php} echo dujun_asset('css/main.css'); {/php}">
{* PJAX 只换 #pjax-container、不换 head，article.css 必须全站加载 *}
<link rel="stylesheet" href="{php} echo dujun_asset('css/article.css'); {/php}">
{php} echo dujun_sitename_style(); {/php}
{$header}
</head>
<body>
<header class="header clearfix">
  <div class="container">
    <div class="column-group">
      <div class="sitename"><a class="index" href="{$host}">{$name}</a></div>
      <div>{php} dujun_header_nav(isset($article) ? $article : null, $type); {/php}</div>
    </div>
  </div>
</header>
<div class="container">
  <div class="column-group">
    <div class="main">
      <div class="rescale-container" id="pjax-container">
{php} dujun_nav_state(isset($article) ? $article : null, $type); {/php}
