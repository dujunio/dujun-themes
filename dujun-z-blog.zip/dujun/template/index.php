{* Template Name:首页、归档与搜索列表 *}
{template:header}
{php} $dujunArticles = dujun_query_articles($articles); {/php}
{if isset($_GET['search'])}
<section class="widget search">
  <form method="post" action="{php} echo dujun_host() . '/'; {/php}">
    <input type="text" name="s" class="search-input" placeholder="输入关键词" autocomplete="on" autofocus>
    {php} echo dujun_icon('search'); {/php}
  </form>
</section>
<div class="sidebar nav-sidebar">{template:sidebar-widgets}</div>
{else}
{php} if ($type != 'index' || dujun_is_custom_query()) { dujun_archive_title(dujun_page_label() !== '' ? dujun_page_label() : $title, dujun_total($pagebar, $dujunArticles)); } {/php}
{foreach $dujunArticles as $article}
{template:post-multi}
{/foreach}
{php} dujun_page_nav($pagebar); {/php}
{/if}
{template:footer}
