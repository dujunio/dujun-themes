<?php
require '../../../zb_system/function/c_system_base.php'; require '../../../zb_system/function/c_system_admin.php'; $zbp->Load(); if (!$zbp->CheckRights('root')) { $zbp->ShowError(6); die(); } if (!$zbp->CheckPlugin('dujun')) { $zbp->ShowError(48); die(); } $dujunFields = array('sitenameFont', 'icpNumber', 'policeNumber', 'footerText', 'dark', 'sidebarTag', 'sidebarArchive'); $dujunDefaults = array( 'sitenameFont' => 'default', 'icpNumber' => '', 'policeNumber' => '', 'footerText' => '', 'dark' => 'auto', 'sidebarTag' => '1', 'sidebarArchive' => '1', ); if (count($_POST) > 0) { CheckIsRefererValid(); $cfg = $zbp->Config('dujun'); foreach ($dujunFields as $f) { $v = GetVars($f, 'POST'); if ($v !== false && $v !== null) { $cfg->$f = (string) $v; } } $zbp->SaveConfig('dujun'); $zbp->SetHint('good'); Redirect($_SERVER['HTTP_REFERER']); } $cfg = $zbp->Config('dujun'); $val = function ($key) use ($cfg, $dujunDefaults) { if (is_object($cfg) && $cfg->HasKey($key) && $cfg->$key !== '') { return (string) $cfg->$key; } return $dujunDefaults[$key]; }; $checked = function ($key, $value) use ($val) { return $val($key) === (string) $value ? ' checked="checked"' : ''; }; $selected = function ($key, $value) use ($val) { return $val($key) === (string) $value ? ' selected="selected"' : ''; }; $fonts = array( 'default' => '默认（跟随主题）', 'pingfang' => '苹方（macOS）', 'hansans' => '思源黑体', 'yahei' => '微软雅黑（Windows）', 'hei' => '黑体 SimHei（Windows）', 'dengxian' => '等线（Windows）', 'heiti' => '华文黑体 / Hiragino（macOS）', 'stxihei' => '华文细黑（macOS）', 'yuanti' => '圆体（macOS）', 'wenquanyi' => '文泉驿微米黑（Linux）', 'hanserif' => '思源宋体（衬线）', 'songti' => '宋体（衬线）', 'kaiti' => '楷体', 'lxgw' => '霞鹜文楷（开源楷体）', 'fangsong' => '仿宋', 'lishu' => '隶书（Windows）', 'helvetica' => 'Helvetica / Arial（西文黑体）', 'georgia' => 'Georgia（西文衬线）', 'times' => 'Times New Roman（西文衬线）', 'mono' => '等宽 Menlo / Consolas', ); require $blogpath . 'zb_system/admin/admin_header.php'; require $blogpath . 'zb_system/admin/admin_top.php'; ?>
<div id="divMain">
  <div class="divHeader">dujun 主题设置</div>
  <div class="SubMenu"></div>
  <div id="divMain2">
    <form action="?save" method="post">
      <input type="hidden" name="csrfToken" value="<?php echo $zbp->GetCsrfToken(); ?>">
      <table width="100%" border="1" class="tableBorder">
        <tr><th scope="col" height="32" width="20%">设置项</th><th>值</th></tr>
        <tr>
          <td height="52">站名字体</td>
          <td><select name="sitenameFont">
            <?php foreach ($fonts as $k => $label) { ?>
            <option value="<?php echo $k; ?>"<?php echo $selected('sitenameFont', $k); ?>><?php echo $label; ?></option>
            <?php } ?>
          </select> <small>仅作用于顶部站名，各选项均带跨平台回退链</small></td>
        </tr>
        <tr><td>ICP 备案号</td><td><input type="text" name="icpNumber" value="<?php echo htmlspecialchars($val('icpNumber')); ?>" size="40"> <small>留空则不显示</small></td></tr>
        <tr><td>公安备案号</td><td><input type="text" name="policeNumber" value="<?php echo htmlspecialchars($val('policeNumber')); ?>" size="40"> <small>留空则不显示</small></td></tr>
        <tr><td>页脚附言</td><td><input type="text" name="footerText" value="<?php echo htmlspecialchars($val('footerText')); ?>" size="60"> <small>显示在版权后面的一句话</small></td></tr>
        <tr><td>配色模式</td><td>
          <label><input type="radio" name="dark" value="auto"<?php echo $checked('dark', 'auto'); ?>> 跟随系统</label>
          <label><input type="radio" name="dark" value="light"<?php echo $checked('dark', 'light'); ?>> 始终亮色</label>
          <label><input type="radio" name="dark" value="dark"<?php echo $checked('dark', 'dark'); ?>> 始终暗色</label>
        </td></tr>
        <tr><td>侧栏标签模块</td><td>
          <label><input type="radio" name="sidebarTag" value="1"<?php echo $checked('sidebarTag', '1'); ?>> 显示</label>
          <label><input type="radio" name="sidebarTag" value="0"<?php echo $checked('sidebarTag', '0'); ?>> 隐藏</label>
        </td></tr>
        <tr><td>侧栏归档模块</td><td>
          <label><input type="radio" name="sidebarArchive" value="1"<?php echo $checked('sidebarArchive', '1'); ?>> 显示</label>
          <label><input type="radio" name="sidebarArchive" value="0"<?php echo $checked('sidebarArchive', '0'); ?>> 隐藏</label>
        </td></tr>
        <tr><td></td><td><input type="submit" class="button" value="保存设置"></td></tr>
      </table>
    </form>
  </div>
</div>
<?php require $blogpath . 'zb_system/admin/admin_footer.php'; ?>
