<?php
 function dujun_render_header(): void { ?>
    <header class="header clearfix">
        <div class="container">
            <div class="column-group">
                <div class="sitename">
                    <a class="index" href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                </div>
                <div>
                    
                    <nav class="clearfix"><?php $djSearchUrl = esc_url(home_url('/')) . '?search'; $djActiveCat = dujun_active_nav_category(); ?><a class="content nav-search<?php if (isset($_GET['search']) || isset($_GET['s'])): ?> active<?php endif; ?>" href="<?php echo $djSearchUrl; ?>"><?php _e('搜索'); ?></a><?php $djNavCats = get_categories(['hide_empty' => false, 'orderby' => 'term_id', 'order' => 'ASC']); foreach ($djNavCats as $djCat): ?><a class="archive<?php if (is_category($djCat->slug) || $djCat->slug === $djActiveCat): ?> active<?php endif; ?>" data-dj-category="<?php echo esc_attr($djCat->slug); ?>" href="<?php echo esc_url(get_term_link($djCat)); ?>"><?php echo dujun_e($djCat->name); ?></a><?php endforeach; ?></nav>
                </div>
            </div>
        </div>
    </header>
    <?php
} function dujun_render_main(): void { ?>
    <div class="container">
        <div class="column-group">
            <div class="main">
                <div class="rescale-container" id="pjax-container"><?php if ('' !== ($djNavCategory = dujun_active_nav_category())): ?><div hidden id="dj-nav-state" data-dj-category="<?php echo esc_attr($djNavCategory); ?>"></div><?php endif; ?>
    <?php
 if (isset($_GET['search'])) { dujun_render_landing(); } elseif (is_singular()) { is_page() ? dujun_render_page() : dujun_render_single(); } elseif (is_search() || is_archive()) { dujun_render_archive_title(); dujun_render_list(); } else { dujun_render_list(); } ?>
                </div>
            </div>
    <?php
 dujun_render_sidebar(); ?>
        </div>
    </div>
    <?php
} function dujun_render_footer(): void { ?>
    <footer class="footer">
        <div class="container">
            <span class="footer-line">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>.</span>
            <span class="footer-line">Powered by <a href="https://wordpress.org" target="_blank" rel="nofollow" style="margin-right:0">WordPress</a>. Theme by <a href="https://dujun.io" target="_blank" rel="nofollow" style="margin-right:0">dujun</a>.</span>
            <?php
 $extras = []; if ($icp = get_theme_mod('icp_number')) { $extras[] = '<a class="footer-beian" href="https://beian.miit.gov.cn" target="_blank" rel="nofollow" style="margin-right:0">' . dujun_e($icp) . '</a>'; } if ($police = get_theme_mod('police_number')) { $extras[] = '<a class="footer-beian" href="https://www.beian.gov.cn" target="_blank" rel="nofollow" style="margin-right:0">' . dujun_e($police) . '</a>'; } if ($ft = get_theme_mod('footer_text')) { $extras[] = dujun_e($ft); } if ($extras) { echo '<span class="footer-line">' . implode('. ', $extras) . '.</span>'; } ?>
        </div>
    </footer>
    <?php
} function dujun_render_sidebar(): void { ?>
    <div class="sidebar">
        <section class="widget search">
            <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <input type="text" name="s" class="search-input"
                       placeholder="<?php _e('输入关键词'); ?>" autocomplete="on">
                <?php echo dujun_icon('search'); ?>
            </form>
        </section>
        <?php dujun_render_sidebar_widgets(); ?>
    </div>
    <?php
} function dujun_render_sidebar_widgets(): void { ?>
    <section class="widget">
        <ul class="widget-list">
            <li>
                <?php $djPages = get_pages(['sort_column' => 'menu_order']); foreach ($djPages as $djPage): ?><a class="content<?php if (is_page($djPage->ID)): ?> active<?php endif; ?>"
                   href="<?php echo esc_url(get_permalink($djPage)); ?>"><?php echo dujun_e(get_the_title($djPage)); ?></a><?php endforeach; ?>
            </li>
        </ul>
    </section>

    <?php if (get_theme_mod('sidebar_tag', '1') !== '0'): ?>
        <section class="widget">
            <span class="widget-title"><?php _e('标签'); ?></span>
            <ul class="widget-list">
                <li>
                    <?php $djTags = get_tags(); foreach ($djTags as $djTag): ?><a class="archive" href="<?php echo esc_url(get_term_link($djTag)); ?>"><?php echo dujun_e($djTag->name); ?></a><?php endforeach; ?>
                </li>
            </ul>
        </section>
    <?php endif; ?>

    <?php if (get_theme_mod('sidebar_archive', '1') !== '0'): ?>
        <section class="widget">
            <span class="widget-title"><?php _e('归档'); ?></span>
            <ul class="widget-list">
                <li class="years">
                    <?php global $wpdb; $djYears = $wpdb->get_col("SELECT DISTINCT YEAR(post_date) FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status = 'publish' ORDER BY post_date DESC"); foreach ($djYears as $djYear): ?><a class="archive" href="<?php echo esc_url(get_year_link((int)$djYear)); ?>"><?php echo (int)$djYear; ?></a><?php endforeach; ?>
                </li>
            </ul>
        </section>
    <?php endif; ?>

    <section class="widget latest-comments">
        <span class="widget-title"><?php _e('评论'); ?></span>
        <ul class="widget-list">
            <?php
 $djComments = get_comments([ 'number' => 5, 'status' => 'approve', 'type' => 'comment', 'parent' => 0, 'user_id' => 0, ]); ?>
            <?php if ($djComments): ?>
                <?php foreach ($djComments as $djC): ?>
                    <?php  ?>
                    <li><a class="content" href="<?php echo esc_url(get_comment_link($djC)); ?>"
                           title="<?php echo dujun_e(dujun_site_date('Y-m-d H:i', strtotime($djC->comment_date))); ?>">
                            <?php echo dujun_e($djC->comment_author ?: '佚名'); ?>: <?php echo dujun_e(wp_strip_all_tags($djC->comment_content)); ?><br>
                            <i class="i-related"></i>《<?php echo dujun_e(get_the_title($djC->comment_post_ID)); ?>》
                        </a></li>
                <?php endforeach; ?>
            <?php else: ?>
                <li><?php _e('暂无评论'); ?></li>
            <?php endif; ?>
        </ul>
    </section>

    <section class="widget">
        <span class="widget-title"><?php _e('其它'); ?></span>
        <ul class="widget-list">
            <?php if (is_user_logged_in()): ?>
                <li><a class="content" href="<?php echo esc_url(admin_url()); ?>"><?php _e('进入后台'); ?> (<?php echo dujun_e(wp_get_current_user()->display_name); ?>)</a></li>
            <?php else: ?>
                <li><a class="content" href="<?php echo esc_url(wp_login_url()); ?>"><?php _e('登录'); ?></a></li>
            <?php endif; ?>
            <li><a class="content" href="<?php echo esc_url(get_bloginfo('rss2_url')); ?>"><?php _e('文章 RSS'); ?></a></li>
            <li><a class="content" href="<?php echo esc_url(get_bloginfo('comments_rss2_url')); ?>"><?php _e('评论 RSS'); ?></a></li>
        </ul>
    </section>
    <?php
} function dujun_render_archive_title(): void { [$title, $total] = dujun_archive_meta(); ?>
    <h3 class="archive-title">
        <?php echo dujun_e($title); ?> <em><?php echo $total; ?></em> 篇
    </h3>
    <?php
} function dujun_render_list(): void { if (have_posts()) : while (have_posts()) : the_post(); $djPost = get_post(); $raw = $djPost ? (string)$djPost->post_content : ''; $cover = dujun_get_post_cover(); $excerpt = dujun_excerpt($raw, 180); $keyword = is_search() ? get_search_query() : ''; if ($keyword !== ''): $djClean = dujun_strip_md_syntax(strip_tags($raw)); if (mb_stripos($djClean, $keyword) === false) { continue; } $excerpt = dujun_strip_md_syntax($excerpt); endif; ?>
            <article>
                <h2 class="article-title">
                    <a class="content" href="<?php the_permalink(); ?>"><?php echo $keyword ? dujun_highlight(dujun_e(get_the_title()), $keyword) : dujun_e(get_the_title()); ?></a>
                </h2>
                <div>
                    <?php if ($cover !== ''): ?>
                        <a class="content" href="<?php the_permalink(); ?>">
                            <div class="summary-cover">
                                <div class="summary-cover-inner">
                                    <img src="<?php echo dujun_e(dujun_https($cover)); ?>" alt="" loading="lazy">
                                </div>
                            </div>
                        </a>
                    <?php endif; ?>
                    <div class="summary-text-inner">
                        <a class="content" href="<?php the_permalink(); ?>"><?php echo $keyword ? dujun_highlight(esc_html($excerpt), $keyword) : esc_html($excerpt); ?></a>
                    </div>
                </div>
                <div class="article-meta clearfix">
                    <span><?php echo dujun_e(dujun_relative_time((int)get_post_timestamp())); ?></span>
                    <?php if (comments_open()): ?>
                        ｜ <a class="content" href="<?php the_permalink(); ?>#comment"><?php
 comments_number(__('评论'), __('1 评论'), __('% 评论')); ?></a>
                    <?php endif; ?>
                </div>
            </article>
        <?php
 endwhile; endif; dujun_page_nav(); } function dujun_render_landing(): void { ?>
    <section class="widget search">
        <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="text" name="s" class="search-input"
                   placeholder="<?php _e('输入关键词'); ?>" autocomplete="on" autofocus>
            <?php echo dujun_icon('search'); ?>
        </form>
    </section>
    <div class="sidebar nav-sidebar">
        <?php dujun_render_sidebar_widgets(); ?>
    </div>
    <?php
} function dujun_render_single(): void { ?>
    <article id="content">
        <h1 class="article-title"><?php the_title(); ?></h1>
        <div class="article-content">
            <?php ob_start(); the_content(); echo dujun_content_images(dujun_content_links(dujun_https(ob_get_clean()))); ?>
        </div>
        <?php if (get_the_tags()): ?>
            <div class="article-tag">
                <?php the_tags('', '', ''); ?>
            </div>
        <?php endif; ?>
        <div class="article-meta clearfix">
            <span><?php echo dujun_e(dujun_chinese_time((int)get_post_timestamp())); ?></span>
            <?php if (is_user_logged_in()): ?>
                ｜ <a class="content" href="<?php echo esc_url(admin_url('post.php?post=' . get_the_ID() . '&action=edit')); ?>" target="_blank" rel="noopener">编辑</a>
            <?php endif; ?>
        </div>
    </article>
    <?php
 dujun_render_comments(); } function dujun_render_page(): void { ?>
    <article id="content">
        <h1 class="article-title"><?php the_title(); ?></h1>
        <div class="article-content">
            <?php ob_start(); the_content(); echo dujun_content_images(dujun_https(ob_get_clean())); ?>
        </div>
        <div class="article-meta clearfix">
            <span><?php echo dujun_e(dujun_site_date('Y 年 m 月 d 日', (int)get_post_timestamp())); ?></span>
        </div>
    </article>
    <?php
 dujun_render_comments(); } function dujun_render_error(): void { ?>
    <div class="error-main">
        <div class="error-container">
            <header class="clearfix">
                <div class="error-title">404</div>
            </header>
            <section>
                <div class="error-text">
                    <p><?php _e('雷霆雨露　俱是天恩'); ?></p>
                </div>
                <a class="index error-button"
                   href="<?php echo esc_url(home_url('/')); ?>"><?php _e('前往首页'); ?></a>
            </section>
            <footer class="error-footer">
                &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>.
            </footer>
        </div>
    </div>
    <?php
} function dujun_render_comments(): void { $djPostId = (int)get_the_ID(); $djMyIds = is_user_logged_in() ? [] : dujun_my_comment_ids(); $djComments = get_comments([ 'post_id' => $djPostId, 'status' => ['approve', 'hold'], 'type' => 'comment', 'orderby' => 'comment_date_gmt', 'order' => 'ASC', ]); $djComments = array_values(array_filter($djComments, static function ($djC) use ($djMyIds) { return '1' === (string)$djC->comment_approved || in_array((int)$djC->comment_ID, $djMyIds, true); })); $GLOBALS['wp_query']->comments = $djComments; $GLOBALS['wp_query']->comment_count = count($djComments); $djNewComment = isset($_GET['unapproved']) ? absint($_GET['unapproved']) : 0; ?>
    <div id="comment"<?php echo $djNewComment ? ' data-new-comment="comment-' . $djNewComment . '"' : ''; ?>>
        <?php if (count($djComments) > 0): ?>
            <span class="widget-title"><?php
 $djCnt = count($djComments); if ($djCnt <= 0) { echo __('暂无评论'); } elseif (1 === $djCnt) { echo __('1 条评论'); } else { echo sprintf(__('%d 条评论'), $djCnt); } ?></span>
            <ul class="comment-list">
                <?php
 $djCommentArgs = [ 'callback' => 'dujun_comment', 'avatar_size' => 40, 'max_depth' => (int)get_option('thread_comments_depth') ?: 3, 'walker' => new Dujun_Walker_Comment(), ]; if (get_option('page_comments')) { $djCommentArgs['page'] = max(1, (int)get_query_var('cpage')); $djCommentArgs['per_page'] = (int)get_option('comments_per_page'); } wp_list_comments($djCommentArgs, $djComments); ?>
            </ul>
            <?php dujun_comments_page_nav(); ?>
        <?php endif; ?>

        <?php if (comments_open($djPostId)): ?>
            <?php
 $djCommenter = wp_get_current_commenter(); $djReqNameEmail = (bool)get_option('require_name_email'); $djUser = wp_get_current_user(); $djRating = get_option('avatar_rating') ?: 'g'; $djHasLogin = is_user_logged_in(); $djRememberAuthor = (!$djHasLogin) ? trim((string)$djCommenter['comment_author']) : ''; $djRememberMail = (!$djHasLogin) ? trim((string)$djCommenter['comment_author_email']) : ''; $djRememberUrl = (!$djHasLogin) ? trim((string)$djCommenter['comment_author_url']) : ''; $djShowAvatar = ('' !== $djRememberAuthor && '' !== $djRememberMail && '' !== $djRememberUrl); $djReplyTo = isset($_GET['replyTo']) ? absint($_GET['replyTo']) : 0; if ($djReplyTo) { $djParent = get_comment($djReplyTo); if (!$djParent || (int)$djParent->comment_post_ID !== (int)$djPostId || '1' !== (string)$djParent->comment_approved) { $djReplyTo = 0; } } ?>
            <div class="comment-form" id="respond-post-<?php echo $djPostId; ?>">
                
                <div class="comment-cancel-reply"><a
                            rel="nofollow" id="cancel-comment-reply-link" href="<?php echo esc_url(get_permalink($djPostId) . '#respond-post-' . $djPostId); ?>"
                            onclick="return WpComment.cancelReply();"
                            style="display:<?php echo $djReplyTo ? 'inline' : 'none'; ?>"><?php _e('取消回复'); ?></a></div>
                <span class="widget-title comment-form-title"><?php _e('添加评论'); ?></span>
                <form method="post" action="<?php echo esc_url(site_url('/wp-comments-post.php')); ?>" class="clearfix">
                    <div class="comment-textarea">
                        <p>
                        <textarea name="comment"
                                  placeholder="<?php _e('说点什么吧'); ?>" required></textarea>
                        </p>
                    </div>
                    <div class="comment-input<?php if ($djShowAvatar): ?> show-avatar<?php endif; ?>">
                        <?php if ($djHasLogin): ?>
                            <img class="admin-avatar"
                                 src="<?php echo esc_url(dujun_avatar_url($djUser->user_email, 80, $djRating)); ?>"
                                 alt="<?php echo dujun_e($djUser->display_name); ?>" width="60" height="60">
                            <span class="admin-name"><?php echo dujun_e($djUser->display_name); ?><a
                                        href="<?php echo esc_url(wp_logout_url(get_permalink($djPostId))); ?>"><?php _e('退出'); ?></a></span>
                        <?php else: ?>
                            <?php if ($djShowAvatar): ?>
                                <img class="guest-avatar"
                                     src="<?php echo esc_url(dujun_avatar_url($djRememberMail, 80, $djRating)); ?>"
                                     alt="<?php echo dujun_e($djRememberAuthor); ?>" width="60" height="60">
                                <span class="guest-name" title="<?php _e('点击修改'); ?>"><?php echo dujun_e($djRememberAuthor); ?></span>
                            <?php endif; ?>
                            <p class="comment-field">
                                <input type="text" name="author" placeholder="<?php _e('名称'); ?>" autocomplete="on"
                                       value="<?php echo esc_attr($djCommenter['comment_author']); ?>"<?php if ($djReqNameEmail): ?> required<?php endif; ?>>
                                <label class="i-comment-author"></label>
                            </p>
                            <p class="comment-field">
                                <input type="email" name="email" placeholder="<?php _e('邮箱'); ?>" autocomplete="on"
                                       value="<?php echo esc_attr($djRememberMail); ?>"<?php if ($djReqNameEmail): ?> required<?php endif; ?>>
                                <label class="i-email"></label>
                            </p>
                            <p class="comment-field">
                                <input type="url" name="url" placeholder="<?php _e('网址'); ?>" autocomplete="on"
                                       value="<?php echo esc_attr($djCommenter['comment_author_url']); ?>">
                                <label class="i-comment-url"></label>
                            </p>
                        <?php endif; ?>
                        <p class="comment-submit">
                            <button type="submit" disabled><?php _e('提交评论'); ?></button>
                        </p>
                    </div>
                    <div class="clearfix"></div>
                    <input type="hidden" name="comment_post_ID" id="comment_post_ID" value="<?php echo $djPostId; ?>">
                    <input type="hidden" name="comment_parent" id="comment_parent" value="<?php echo (int)$djReplyTo; ?>">
                    <?php
 ?>
                    <input type="hidden" name="wp-comment-cookies-consent" value="yes">
                    <?php
 if (current_user_can('unfiltered_html')) { wp_nonce_field('unfiltered-html-comment_' . $djPostId, '_wp_unfiltered_html_comment', false); } ?>
                </form>
            </div>
        <?php else: ?>
            <span class="widget-title"><?php _e('评论已关闭'); ?></span>
        <?php endif; ?>
    </div>
    <?php
} 